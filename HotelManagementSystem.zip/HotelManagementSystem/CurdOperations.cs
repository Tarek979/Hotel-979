﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public class CurdOperations
    {

        private DataAccess da = new DataAccess();
        public void loadGridView(DataGridView dgv, string sql)
        {
            try
            {
                var ds = this.da.ExecuteQuery(sql);
                dgv.AutoGenerateColumns = false;
                dgv.DataSource = ds.Tables[0];
                dgv.ClearSelection();
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occurred: " + exc.Message);
            }
        }

        public void DeleteData(DataGridView dgv, string tableName, string primaryColumn)
        {
            if (dgv.SelectedRows.Count < 1)
            {
                MessageBox.Show("Please select a row first to delete", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                var id = dgv.CurrentRow.Cells[primaryColumn].Value.ToString();
               

                DialogResult dr = MessageBox.Show("Are you sure you want to delete", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (dr == DialogResult.No)
                {
                    return;
                }

                var query = "DELETE FROM " + tableName + " WHERE " + primaryColumn + " = '" + id + "';";
                var count = this.da.ExecuteDMLQuery(query);

                if (count == 1)
                {
                    MessageBox.Show(id.ToUpper() + " has been removed from the list.");
                }
                else
                {
                    MessageBox.Show("Data remove failed");
                }

               
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occurred: " + exc.Message);
            }
        }


        public void SaveData(string query, string sqlUpdate, string sqlInsert, bool isValid)
        {
            try
            {
                if (!isValid)
                {
                   
                    return;
                }

                var dt = this.da.ExecuteQueryTable(query);

                if (dt.Rows.Count == 1)
                {
                    //update operation
                    int count = this.da.ExecuteDMLQuery(sqlUpdate);

                    if (count == 1)
                        MessageBox.Show("Data updated Properly");
                    else
                        MessageBox.Show("Data upgradation failed");
                }
                else if (dt.Rows.Count == 0)
                {
                    //insert operation
                    int count = this.da.ExecuteDMLQuery(sqlInsert);

                    if (count == 1)
                        MessageBox.Show("Data Added Properly");
                    else
                        MessageBox.Show("Data insertion failure");
                }

                
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }

        public void SearchData(DataGridView dgv,String sql) 
        {
            try
            {
                DataSet ds = this.da.ExecuteQuery(sql);
                dgv.DataSource = ds.Tables[0];
            }
            catch (Exception exc) 
            {
                MessageBox.Show("An error has occured: " + exc.Message);
            }
        }


    }
}
