﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlReceptionist : UserControl
    {
        private UserControl current;
          
       
        private void navigateScreens(UserControl uc)
        {
            this.groupBoxAdminUserControlls.Controls.Remove(current);
            this.current = uc;
            this.groupBoxAdminUserControlls.Controls.Add(current);
        }
        private void changeTextAndColor(Button Button)
        {
            this.labelAdminHeader.Text = Button.Text;
            this.panelTopBar.BackColor = Button.BackColor;

        }
        private void SignOut()
        {
            UserControlLogin ucLogin = new UserControlLogin();
            FormMain fromm = (FormMain)this.ParentForm;
            fromm.panelMain.Controls.Remove(this);
            fromm.panelMain.Controls.Add(ucLogin);
        }
         public UserControlReceptionist()
        {
            InitializeComponent();
            UserControlReceptionistCustomerEntry ucad = new UserControlReceptionistCustomerEntry();
            this.current=ucad;
            this.groupBoxAdminUserControlls.Controls.Add(current);

        }

        private void labelSignout_Click(object sender, EventArgs e)
        {
            SignOut();
        }

        private void pictureBoxSignout_Click(object sender, EventArgs e)
        {
            SignOut();
        }

        private void buttonCustomerEntry_Click(object sender, EventArgs e)
        {
            UserControlReceptionistCustomerEntry ucrce= new UserControlReceptionistCustomerEntry();
            string sql = "select * from Customers ";
            this.changeTextAndColor(buttonCustomerEntry);
            this.navigateScreens(ucrce);
           


        }

        private void buttonRooms_Click(object sender, EventArgs e)
        {
            UserControlReceptionistManageBookings ucrbr = new UserControlReceptionistManageBookings();
            this.changeTextAndColor(buttonRooms);
            this.navigateScreens(ucrbr);
        }

        private void buttonCheckIn_Click(object sender, EventArgs e)
        {
            UserControlReceptionistCheckIn ucrci=  new UserControlReceptionistCheckIn();
            this.changeTextAndColor(buttonCheckIn);
            this.navigateScreens(ucrci);
        }

        private void buttonCheckOut_Click(object sender, EventArgs e)
        {
            UserControlReceptionistCheckOut ucrco= new UserControlReceptionistCheckOut();
            this.changeTextAndColor(buttonCheckOut);
            this.navigateScreens(ucrco);
        }

        private void buttonReservation_Click(object sender, EventArgs e)
        {
            UserControlReceptionistManageReservations ucrmr= new UserControlReceptionistManageReservations();
            this.changeTextAndColor(buttonReservation);
            this.navigateScreens(ucrmr);
        }

        private void buttonPayments_Click(object sender, EventArgs e)
        {
            UserControlReceptionistManagePayemnt ucrmp=new UserControlReceptionistManagePayemnt();
            this.changeTextAndColor(buttonPayments);
            this.navigateScreens(ucrmp);
        }
    }
}
