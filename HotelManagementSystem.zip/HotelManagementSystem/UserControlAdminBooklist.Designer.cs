﻿namespace HotelManagementSystem
{
    partial class UserControlAdminBooklist
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dgvBooking = new System.Windows.Forms.DataGridView();
            this.labelSearch = new System.Windows.Forms.Label();
            this.labelBookingTitle = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelBooked = new System.Windows.Forms.Label();
            this.labelBookedNumber = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelPayemntPending = new System.Windows.Forms.Label();
            this.labelPayemntPendingNumber = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelIncome = new System.Windows.Forms.Label();
            this.labelIncomeNumber = new System.Windows.Forms.Label();
            this.labelStats = new System.Windows.Forms.Label();
            this.ReceptionistID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RoomId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RoomNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CheckInDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CheckOutDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooking)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(37, 206);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(701, 20);
            this.textBox1.TabIndex = 45;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(744, 203);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 27);
            this.button1.TabIndex = 44;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // dgvBooking
            // 
            this.dgvBooking.AllowUserToAddRows = false;
            this.dgvBooking.AllowUserToDeleteRows = false;
            this.dgvBooking.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBooking.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ReceptionistID,
            this.RoomId,
            this.RoomNumber,
            this.CustomerID,
            this.UserName,
            this.Phone,
            this.CheckInDate,
            this.CheckOutDate,
            this.Price,
            this.PaymentStatus});
            this.dgvBooking.Location = new System.Drawing.Point(13, 236);
            this.dgvBooking.Name = "dgvBooking";
            this.dgvBooking.ReadOnly = true;
            this.dgvBooking.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvBooking.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBooking.Size = new System.Drawing.Size(872, 273);
            this.dgvBooking.TabIndex = 42;
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.Location = new System.Drawing.Point(33, 184);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(115, 19);
            this.labelSearch.TabIndex = 43;
            this.labelSearch.Text = "Search Bookings";
            // 
            // labelBookingTitle
            // 
            this.labelBookingTitle.AutoSize = true;
            this.labelBookingTitle.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBookingTitle.Location = new System.Drawing.Point(29, 21);
            this.labelBookingTitle.Name = "labelBookingTitle";
            this.labelBookingTitle.Size = new System.Drawing.Size(207, 45);
            this.labelBookingTitle.TabIndex = 41;
            this.labelBookingTitle.Text = "Booking List";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.labelBooked);
            this.panel1.Controls.Add(this.labelBookedNumber);
            this.panel1.Location = new System.Drawing.Point(37, 89);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(255, 92);
            this.panel1.TabIndex = 46;
            // 
            // labelBooked
            // 
            this.labelBooked.AutoSize = true;
            this.labelBooked.BackColor = System.Drawing.Color.Transparent;
            this.labelBooked.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBooked.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelBooked.Location = new System.Drawing.Point(19, 3);
            this.labelBooked.Name = "labelBooked";
            this.labelBooked.Size = new System.Drawing.Size(217, 29);
            this.labelBooked.TabIndex = 48;
            this.labelBooked.Text = "Total Rooms Booked";
            // 
            // labelBookedNumber
            // 
            this.labelBookedNumber.AutoSize = true;
            this.labelBookedNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelBookedNumber.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBookedNumber.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelBookedNumber.Location = new System.Drawing.Point(87, 30);
            this.labelBookedNumber.Name = "labelBookedNumber";
            this.labelBookedNumber.Size = new System.Drawing.Size(73, 59);
            this.labelBookedNumber.TabIndex = 49;
            this.labelBookedNumber.Text = "00";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.labelPayemntPending);
            this.panel2.Controls.Add(this.labelPayemntPendingNumber);
            this.panel2.Location = new System.Drawing.Point(327, 89);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(255, 92);
            this.panel2.TabIndex = 47;
            // 
            // labelPayemntPending
            // 
            this.labelPayemntPending.AutoSize = true;
            this.labelPayemntPending.BackColor = System.Drawing.Color.Transparent;
            this.labelPayemntPending.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPayemntPending.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelPayemntPending.Location = new System.Drawing.Point(34, 3);
            this.labelPayemntPending.Name = "labelPayemntPending";
            this.labelPayemntPending.Size = new System.Drawing.Size(198, 29);
            this.labelPayemntPending.TabIndex = 50;
            this.labelPayemntPending.Text = "Pending Payments";
            // 
            // labelPayemntPendingNumber
            // 
            this.labelPayemntPendingNumber.AutoSize = true;
            this.labelPayemntPendingNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelPayemntPendingNumber.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPayemntPendingNumber.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelPayemntPendingNumber.Location = new System.Drawing.Point(91, 30);
            this.labelPayemntPendingNumber.Name = "labelPayemntPendingNumber";
            this.labelPayemntPendingNumber.Size = new System.Drawing.Size(73, 59);
            this.labelPayemntPendingNumber.TabIndex = 51;
            this.labelPayemntPendingNumber.Text = "00";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel3.Controls.Add(this.labelIncome);
            this.panel3.Controls.Add(this.labelIncomeNumber);
            this.panel3.Location = new System.Drawing.Point(619, 89);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(255, 92);
            this.panel3.TabIndex = 47;
            // 
            // labelIncome
            // 
            this.labelIncome.AutoSize = true;
            this.labelIncome.BackColor = System.Drawing.Color.Transparent;
            this.labelIncome.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIncome.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelIncome.Location = new System.Drawing.Point(56, 3);
            this.labelIncome.Name = "labelIncome";
            this.labelIncome.Size = new System.Drawing.Size(141, 29);
            this.labelIncome.TabIndex = 52;
            this.labelIncome.Text = "Total Income";
            // 
            // labelIncomeNumber
            // 
            this.labelIncomeNumber.AutoSize = true;
            this.labelIncomeNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelIncomeNumber.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIncomeNumber.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelIncomeNumber.Location = new System.Drawing.Point(51, 30);
            this.labelIncomeNumber.Name = "labelIncomeNumber";
            this.labelIncomeNumber.Size = new System.Drawing.Size(169, 59);
            this.labelIncomeNumber.TabIndex = 53;
            this.labelIncomeNumber.Text = "$00000";
            // 
            // labelStats
            // 
            this.labelStats.AutoSize = true;
            this.labelStats.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStats.Location = new System.Drawing.Point(33, 67);
            this.labelStats.Name = "labelStats";
            this.labelStats.Size = new System.Drawing.Size(41, 19);
            this.labelStats.TabIndex = 48;
            this.labelStats.Text = "Stats";
            // 
            // ReceptionistID
            // 
            this.ReceptionistID.DataPropertyName = "BookingId";
            this.ReceptionistID.HeaderText = "BookingID";
            this.ReceptionistID.Name = "ReceptionistID";
            this.ReceptionistID.ReadOnly = true;
            this.ReceptionistID.Width = 70;
            // 
            // RoomId
            // 
            this.RoomId.DataPropertyName = "RoomId";
            this.RoomId.HeaderText = "RoomId";
            this.RoomId.Name = "RoomId";
            this.RoomId.ReadOnly = true;
            this.RoomId.Width = 70;
            // 
            // RoomNumber
            // 
            this.RoomNumber.DataPropertyName = "RoomNumber";
            this.RoomNumber.HeaderText = "Room Number";
            this.RoomNumber.Name = "RoomNumber";
            this.RoomNumber.ReadOnly = true;
            this.RoomNumber.Width = 70;
            // 
            // CustomerID
            // 
            this.CustomerID.DataPropertyName = "CustomerID";
            this.CustomerID.HeaderText = "CustomerID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.Width = 70;
            // 
            // UserName
            // 
            this.UserName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.UserName.DataPropertyName = "CustomerName";
            this.UserName.HeaderText = "Customer Name";
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            // 
            // Phone
            // 
            this.Phone.DataPropertyName = "CustomerNumber";
            this.Phone.HeaderText = "PhoneNumber";
            this.Phone.Name = "Phone";
            this.Phone.ReadOnly = true;
            this.Phone.Width = 80;
            // 
            // CheckInDate
            // 
            this.CheckInDate.DataPropertyName = "CheckInDate";
            this.CheckInDate.HeaderText = "Check-in";
            this.CheckInDate.Name = "CheckInDate";
            this.CheckInDate.ReadOnly = true;
            // 
            // CheckOutDate
            // 
            this.CheckOutDate.DataPropertyName = "CheckOutDate";
            this.CheckOutDate.HeaderText = "Check-out";
            this.CheckOutDate.Name = "CheckOutDate";
            this.CheckOutDate.ReadOnly = true;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 80;
            // 
            // PaymentStatus
            // 
            this.PaymentStatus.DataPropertyName = "PaymentStatus";
            this.PaymentStatus.HeaderText = "Payment Status";
            this.PaymentStatus.Name = "PaymentStatus";
            this.PaymentStatus.ReadOnly = true;
            this.PaymentStatus.Width = 80;
            // 
            // UserControlAdminBooklist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.labelStats);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgvBooking);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.labelBookingTitle);
            this.Name = "UserControlAdminBooklist";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Size = new System.Drawing.Size(912, 550);
            this.Load += new System.EventHandler(this.UserControlAdminBooklist_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooking)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.Label labelBookingTitle;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelBooked;
        private System.Windows.Forms.Label labelBookedNumber;
        private System.Windows.Forms.Label labelPayemntPending;
        private System.Windows.Forms.Label labelPayemntPendingNumber;
        private System.Windows.Forms.Label labelIncome;
        private System.Windows.Forms.Label labelIncomeNumber;
        private System.Windows.Forms.Label labelStats;
        private System.Windows.Forms.DataGridView dgvBooking;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceptionistID;
        private System.Windows.Forms.DataGridViewTextBoxColumn RoomId;
        private System.Windows.Forms.DataGridViewTextBoxColumn RoomNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn CheckInDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CheckOutDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentStatus;
    }
}
