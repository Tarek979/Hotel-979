﻿namespace HotelManagementSystem
{
    partial class UserControlAdminDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlAdminDashboard));
            this.panelAdminDashboardSidebar = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.labelRecentName = new System.Windows.Forms.Label();
            this.labelpayment = new System.Windows.Forms.Label();
            this.labelCheckin = new System.Windows.Forms.Label();
            this.labelNum = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelRecentName2 = new System.Windows.Forms.Label();
            this.labelpayment2 = new System.Windows.Forms.Label();
            this.labelCheckin2 = new System.Windows.Forms.Label();
            this.labelNum2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelRecentName1 = new System.Windows.Forms.Label();
            this.labelpayment1 = new System.Windows.Forms.Label();
            this.labelCheckin1 = new System.Windows.Forms.Label();
            this.labelNum1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelAdminDashboardMainBar = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.labelReservationsNumber = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.labelRecepNumber = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelIncome = new System.Windows.Forms.Label();
            this.labelIncomeNumber = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.labelRooms = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labelAdminDashboardWelcomeText = new System.Windows.Forms.Label();
            this.panelAdminDashboardSidebar.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelAdminDashboardMainBar.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAdminDashboardSidebar
            // 
            this.panelAdminDashboardSidebar.Controls.Add(this.panel4);
            this.panelAdminDashboardSidebar.Controls.Add(this.panel2);
            this.panelAdminDashboardSidebar.Controls.Add(this.panel1);
            this.panelAdminDashboardSidebar.Controls.Add(this.label2);
            this.panelAdminDashboardSidebar.Controls.Add(this.pictureBox1);
            this.panelAdminDashboardSidebar.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelAdminDashboardSidebar.Location = new System.Drawing.Point(599, 0);
            this.panelAdminDashboardSidebar.Name = "panelAdminDashboardSidebar";
            this.panelAdminDashboardSidebar.Size = new System.Drawing.Size(313, 550);
            this.panelAdminDashboardSidebar.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel4.Controls.Add(this.labelRecentName);
            this.panel4.Controls.Add(this.labelpayment);
            this.panel4.Controls.Add(this.labelCheckin);
            this.panel4.Controls.Add(this.labelNum);
            this.panel4.Location = new System.Drawing.Point(25, 259);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(258, 52);
            this.panel4.TabIndex = 8;
            // 
            // labelRecentName
            // 
            this.labelRecentName.AutoSize = true;
            this.labelRecentName.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRecentName.ForeColor = System.Drawing.Color.Black;
            this.labelRecentName.Location = new System.Drawing.Point(3, 10);
            this.labelRecentName.Name = "labelRecentName";
            this.labelRecentName.Size = new System.Drawing.Size(43, 15);
            this.labelRecentName.TabIndex = 3;
            this.labelRecentName.Text = "xxxxxx";
            // 
            // labelpayment
            // 
            this.labelpayment.AutoSize = true;
            this.labelpayment.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpayment.ForeColor = System.Drawing.Color.Green;
            this.labelpayment.Location = new System.Drawing.Point(203, 28);
            this.labelpayment.Name = "labelpayment";
            this.labelpayment.Size = new System.Drawing.Size(32, 15);
            this.labelpayment.TabIndex = 6;
            this.labelpayment.Text = "Paid";
            this.labelpayment.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelCheckin
            // 
            this.labelCheckin.AutoSize = true;
            this.labelCheckin.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCheckin.Location = new System.Drawing.Point(185, 10);
            this.labelCheckin.Name = "labelCheckin";
            this.labelCheckin.Size = new System.Drawing.Size(71, 15);
            this.labelCheckin.TabIndex = 4;
            this.labelCheckin.Text = "23-04-2023";
            // 
            // labelNum
            // 
            this.labelNum.AutoSize = true;
            this.labelNum.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNum.Location = new System.Drawing.Point(3, 28);
            this.labelNum.Name = "labelNum";
            this.labelNum.Size = new System.Drawing.Size(70, 15);
            this.labelNum.TabIndex = 5;
            this.labelNum.Text = "000000000";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel2.Controls.Add(this.labelRecentName2);
            this.panel2.Controls.Add(this.labelpayment2);
            this.panel2.Controls.Add(this.labelCheckin2);
            this.panel2.Controls.Add(this.labelNum2);
            this.panel2.Location = new System.Drawing.Point(25, 405);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(258, 52);
            this.panel2.TabIndex = 8;
            // 
            // labelRecentName2
            // 
            this.labelRecentName2.AutoSize = true;
            this.labelRecentName2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRecentName2.ForeColor = System.Drawing.Color.Black;
            this.labelRecentName2.Location = new System.Drawing.Point(3, 10);
            this.labelRecentName2.Name = "labelRecentName2";
            this.labelRecentName2.Size = new System.Drawing.Size(43, 15);
            this.labelRecentName2.TabIndex = 3;
            this.labelRecentName2.Text = "xxxxxx";
            // 
            // labelpayment2
            // 
            this.labelpayment2.AutoSize = true;
            this.labelpayment2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpayment2.ForeColor = System.Drawing.Color.Green;
            this.labelpayment2.Location = new System.Drawing.Point(204, 28);
            this.labelpayment2.Name = "labelpayment2";
            this.labelpayment2.Size = new System.Drawing.Size(51, 15);
            this.labelpayment2.TabIndex = 6;
            this.labelpayment2.Text = "Pending";
            this.labelpayment2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelCheckin2
            // 
            this.labelCheckin2.AutoSize = true;
            this.labelCheckin2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCheckin2.Location = new System.Drawing.Point(185, 10);
            this.labelCheckin2.Name = "labelCheckin2";
            this.labelCheckin2.Size = new System.Drawing.Size(71, 15);
            this.labelCheckin2.TabIndex = 4;
            this.labelCheckin2.Text = "20-04-2023";
            // 
            // labelNum2
            // 
            this.labelNum2.AutoSize = true;
            this.labelNum2.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNum2.Location = new System.Drawing.Point(3, 28);
            this.labelNum2.Name = "labelNum2";
            this.labelNum2.Size = new System.Drawing.Size(70, 15);
            this.labelNum2.TabIndex = 5;
            this.labelNum2.Text = "000000000";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.panel1.Controls.Add(this.labelRecentName1);
            this.panel1.Controls.Add(this.labelpayment1);
            this.panel1.Controls.Add(this.labelCheckin1);
            this.panel1.Controls.Add(this.labelNum1);
            this.panel1.Location = new System.Drawing.Point(25, 331);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(258, 52);
            this.panel1.TabIndex = 7;
            // 
            // labelRecentName1
            // 
            this.labelRecentName1.AutoSize = true;
            this.labelRecentName1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRecentName1.ForeColor = System.Drawing.Color.Black;
            this.labelRecentName1.Location = new System.Drawing.Point(3, 10);
            this.labelRecentName1.Name = "labelRecentName1";
            this.labelRecentName1.Size = new System.Drawing.Size(43, 15);
            this.labelRecentName1.TabIndex = 3;
            this.labelRecentName1.Text = "xxxxxx";
            // 
            // labelpayment1
            // 
            this.labelpayment1.AutoSize = true;
            this.labelpayment1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpayment1.ForeColor = System.Drawing.Color.Green;
            this.labelpayment1.Location = new System.Drawing.Point(223, 28);
            this.labelpayment1.Name = "labelpayment1";
            this.labelpayment1.Size = new System.Drawing.Size(32, 15);
            this.labelpayment1.TabIndex = 6;
            this.labelpayment1.Text = "Paid";
            this.labelpayment1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelCheckin1
            // 
            this.labelCheckin1.AutoSize = true;
            this.labelCheckin1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCheckin1.Location = new System.Drawing.Point(185, 10);
            this.labelCheckin1.Name = "labelCheckin1";
            this.labelCheckin1.Size = new System.Drawing.Size(71, 15);
            this.labelCheckin1.TabIndex = 4;
            this.labelCheckin1.Text = "22-04-2023";
            // 
            // labelNum1
            // 
            this.labelNum1.AutoSize = true;
            this.labelNum1.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNum1.Location = new System.Drawing.Point(3, 28);
            this.labelNum1.Name = "labelNum1";
            this.labelNum1.Size = new System.Drawing.Size(70, 15);
            this.labelNum1.TabIndex = 5;
            this.labelNum1.Text = "000000000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Recent Booking List";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(25, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(273, 173);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelAdminDashboardMainBar
            // 
            this.panelAdminDashboardMainBar.Controls.Add(this.panel6);
            this.panelAdminDashboardMainBar.Controls.Add(this.panel7);
            this.panelAdminDashboardMainBar.Controls.Add(this.panel5);
            this.panelAdminDashboardMainBar.Controls.Add(this.panel3);
            this.panelAdminDashboardMainBar.Controls.Add(this.label1);
            this.panelAdminDashboardMainBar.Controls.Add(this.labelAdminDashboardWelcomeText);
            this.panelAdminDashboardMainBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelAdminDashboardMainBar.Location = new System.Drawing.Point(0, 0);
            this.panelAdminDashboardMainBar.Name = "panelAdminDashboardMainBar";
            this.panelAdminDashboardMainBar.Size = new System.Drawing.Size(599, 550);
            this.panelAdminDashboardMainBar.TabIndex = 1;
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.labelReservationsNumber);
            this.panel6.Location = new System.Drawing.Point(289, 359);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(230, 116);
            this.panel6.TabIndex = 9;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(3, 81);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(143, 29);
            this.label19.TabIndex = 58;
            this.label19.Text = "Reservations";
            // 
            // labelReservationsNumber
            // 
            this.labelReservationsNumber.AutoSize = true;
            this.labelReservationsNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelReservationsNumber.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelReservationsNumber.ForeColor = System.Drawing.Color.Black;
            this.labelReservationsNumber.Location = new System.Drawing.Point(3, 1);
            this.labelReservationsNumber.Name = "labelReservationsNumber";
            this.labelReservationsNumber.Size = new System.Drawing.Size(73, 59);
            this.labelReservationsNumber.TabIndex = 59;
            this.labelReservationsNumber.Text = "50";
            // 
            // panel7
            // 
            this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel7.Controls.Add(this.label11);
            this.panel7.Controls.Add(this.labelRecepNumber);
            this.panel7.Location = new System.Drawing.Point(55, 287);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(206, 194);
            this.panel7.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(14, 153);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(148, 29);
            this.label11.TabIndex = 56;
            this.label11.Text = "Receptionists";
            // 
            // labelRecepNumber
            // 
            this.labelRecepNumber.AutoSize = true;
            this.labelRecepNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelRecepNumber.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRecepNumber.ForeColor = System.Drawing.Color.White;
            this.labelRecepNumber.Location = new System.Drawing.Point(16, 105);
            this.labelRecepNumber.Name = "labelRecepNumber";
            this.labelRecepNumber.Size = new System.Drawing.Size(73, 59);
            this.labelRecepNumber.TabIndex = 57;
            this.labelRecepNumber.Text = "50";
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel5.Controls.Add(this.labelIncome);
            this.panel5.Controls.Add(this.labelIncomeNumber);
            this.panel5.Location = new System.Drawing.Point(289, 121);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(230, 206);
            this.panel5.TabIndex = 7;
            // 
            // labelIncome
            // 
            this.labelIncome.AutoSize = true;
            this.labelIncome.BackColor = System.Drawing.Color.Transparent;
            this.labelIncome.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIncome.ForeColor = System.Drawing.Color.Black;
            this.labelIncome.Location = new System.Drawing.Point(45, 85);
            this.labelIncome.Name = "labelIncome";
            this.labelIncome.Size = new System.Drawing.Size(141, 29);
            this.labelIncome.TabIndex = 54;
            this.labelIncome.Text = "Total Income";
            // 
            // labelIncomeNumber
            // 
            this.labelIncomeNumber.AutoSize = true;
            this.labelIncomeNumber.BackColor = System.Drawing.Color.Transparent;
            this.labelIncomeNumber.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIncomeNumber.ForeColor = System.Drawing.Color.Black;
            this.labelIncomeNumber.Location = new System.Drawing.Point(29, 104);
            this.labelIncomeNumber.Name = "labelIncomeNumber";
            this.labelIncomeNumber.Size = new System.Drawing.Size(169, 59);
            this.labelIncomeNumber.TabIndex = 55;
            this.labelIncomeNumber.Text = "$00000";
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.labelRooms);
            this.panel3.Location = new System.Drawing.Point(55, 121);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(206, 137);
            this.panel3.TabIndex = 6;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Yellow;
            this.label13.Location = new System.Drawing.Point(65, 105);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 29);
            this.label13.TabIndex = 58;
            this.label13.Text = "Rooms";
            // 
            // labelRooms
            // 
            this.labelRooms.AutoSize = true;
            this.labelRooms.BackColor = System.Drawing.Color.Transparent;
            this.labelRooms.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelRooms.ForeColor = System.Drawing.Color.Yellow;
            this.labelRooms.Location = new System.Drawing.Point(64, 58);
            this.labelRooms.Name = "labelRooms";
            this.labelRooms.Size = new System.Drawing.Size(97, 59);
            this.labelRooms.TabIndex = 59;
            this.labelRooms.Text = "60+";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(234, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Your hotel is  doing  great ! Start Managing now!";
            // 
            // labelAdminDashboardWelcomeText
            // 
            this.labelAdminDashboardWelcomeText.AutoSize = true;
            this.labelAdminDashboardWelcomeText.Font = new System.Drawing.Font("Calibri", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdminDashboardWelcomeText.Location = new System.Drawing.Point(33, 44);
            this.labelAdminDashboardWelcomeText.Name = "labelAdminDashboardWelcomeText";
            this.labelAdminDashboardWelcomeText.Size = new System.Drawing.Size(170, 42);
            this.labelAdminDashboardWelcomeText.TabIndex = 0;
            this.labelAdminDashboardWelcomeText.Text = "Welcome !";
            // 
            // UserControlAdminDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelAdminDashboardMainBar);
            this.Controls.Add(this.panelAdminDashboardSidebar);
            this.Name = "UserControlAdminDashboard";
            this.Size = new System.Drawing.Size(912, 550);
            this.Load += new System.EventHandler(this.UserControlAdminDashboard_Load);
            this.panelAdminDashboardSidebar.ResumeLayout(false);
            this.panelAdminDashboardSidebar.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelAdminDashboardMainBar.ResumeLayout(false);
            this.panelAdminDashboardMainBar.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelAdminDashboardSidebar;
        private System.Windows.Forms.Panel panelAdminDashboardMainBar;
        private System.Windows.Forms.Label labelAdminDashboardWelcomeText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label labelRecentName;
        private System.Windows.Forms.Label labelpayment;
        private System.Windows.Forms.Label labelCheckin;
        private System.Windows.Forms.Label labelNum;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelRecentName2;
        private System.Windows.Forms.Label labelpayment2;
        private System.Windows.Forms.Label labelCheckin2;
        private System.Windows.Forms.Label labelNum2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelRecentName1;
        private System.Windows.Forms.Label labelpayment1;
        private System.Windows.Forms.Label labelCheckin1;
        private System.Windows.Forms.Label labelNum1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelIncome;
        private System.Windows.Forms.Label labelIncomeNumber;
        private System.Windows.Forms.Label labelRecepNumber;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label labelReservationsNumber;
        private System.Windows.Forms.Label labelRooms;
    }
}
