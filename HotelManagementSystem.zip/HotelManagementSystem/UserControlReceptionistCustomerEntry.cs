﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlReceptionistCustomerEntry : UserControl
    {
        private CurdOperations co = new CurdOperations();
        public DataGridView dgv
        {
            get { return this.dgvCustomers; }
        }
        public UserControlReceptionistCustomerEntry()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvCustomers, "select * from Customers;");
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.co.SearchData(this.dgvCustomers, "select * from Customers where CustomerId='" + textBoxSearch.Text + "';   ");
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            this.co.DeleteData(this.dgvCustomers, "Customers", "CustomerId");
            this.co.loadGridView(this.dgvCustomers, "select * from Customers;");
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            this.textBoxCusID.Text = this.dgvCustomers.CurrentRow.Cells[0].Value.ToString();
            this.textBoxCName.Text = this.dgvCustomers.CurrentRow.Cells[1].Value.ToString();
            this.comboBoxGender.Text = this.dgvCustomers.CurrentRow.Cells[2].Value.ToString();
            this.textBoxEmail.Text = this.dgvCustomers.CurrentRow.Cells[3].Value.ToString();
            this.textBoxPhone.Text = this.dgvCustomers.CurrentRow.Cells[4].Value.ToString();
            this.textBoxAddress.Text = this.dgvCustomers.CurrentRow.Cells[5].Value.ToString();
           
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool isValid = IsValidToSave();
            var query = "select * from Customers where CustomerId = '" + this.textBoxCusID.Text + "'";
            var sqlUpdate = @"update Customers
                      set Name = '" + this.textBoxCName.Text + @"',
                      Gender = '" + this.comboBoxGender.Text + @"',
                      Email = '" + this.textBoxEmail.Text + @"',
                      Phone = '" + this.textBoxPhone.Text + @"',
                      Address = '" + this.textBoxAddress.Text + @"'
                      where CustomerId = '" + this.textBoxCusID.Text + "';";
            var sqlInsert = "insert into Customers values('" + this.textBoxCusID.Text + "', '" + this.textBoxCName.Text + "', '" + this.comboBoxGender.Text + "', '" + this.textBoxEmail.Text + "', '" + this.textBoxPhone.Text + "', '" + this.textBoxAddress.Text + "'); ";


            this.co.SaveData(query, sqlUpdate, sqlInsert, isValid);
            this.co.loadGridView(this.dgvCustomers, "select * from Customers;");
        }

        private bool IsValidToSave()
        {
            if (string.IsNullOrWhiteSpace(this.textBoxCusID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCName.Text) ||
                string.IsNullOrWhiteSpace(this.comboBoxGender.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxEmail.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxPhone.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxAddress.Text))
            {
                MessageBox.Show("Please fill up all the values");
                return false;
            }
            return true;
        }
    }
}
