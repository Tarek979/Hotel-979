﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlAdminDashboard : UserControl
    {
        private DataAccess da = new DataAccess();
        public List<(string customerName, string number, string paymentStatus, DateTime checkin)> GetBookingsData(int indexOf)
        {
            try 
            {
                var sql = "SELECT CustomerName, CustomerNumber, PaymentStatus, CheckInDate FROM Bookings ORDER BY CheckInDate DESC;";
                var ds = this.da.ExecuteQuery(sql);

                var bookingsData = new List<(string, string, string, DateTime)>();
                var row = ds.Tables[0].Rows[indexOf];
                var customerName = row["CustomerName"].ToString();
                var number = row["CustomerNumber"].ToString();
                var paymentStatus = row["PaymentStatus"].ToString();
                var checkin = DateTime.Parse(row["CheckInDate"].ToString());

                bookingsData.Add((customerName, number, paymentStatus, checkin));
                return bookingsData;
            }
            catch (Exception exc)
            {
                MessageBox.Show("An error has occured: " + exc.Message);
                var bookingsData = new List<(string, string, string, DateTime)>();
                var customerName = "Failed to load";
                var number = "Failed to load";
                var paymentStatus = "Failed to load";
                var checkin = DateTime.Parse("2000-00-0");
                bookingsData.Add((customerName, number, paymentStatus, checkin));
                return bookingsData;
            }
        }
        private int GetRowCount(string query = "select * from Bookings;")
        {

            var dt = this.da.ExecuteQueryTable(query);
            int rows = dt.Rows.Count;
            return rows;

        }
        private string GetSum(string query = "SELECT SUM(CAST(Price AS DECIMAL(10, 2))) AS TotalPrice FROM Bookings;")
        {

            var dt = this.da.ExecuteQueryTable(query);
            string sum = "$";
            sum += dt.Rows[0][0].ToString();
            return (sum);

        }
        public UserControlAdminDashboard()
        {
            InitializeComponent();
        }

        private void UserControlAdminDashboard_Load(object sender, EventArgs e)
        {
            this.labelRecepNumber.Text = GetRowCount("select * from Receptionists").ToString();
            this.labelReservationsNumber.Text = GetRowCount("select * from Reservation").ToString();
            this.labelRooms.Text = GetRowCount("select * from Rooms").ToString();
            this.labelIncomeNumber.Text = GetSum("SELECT SUM(CAST(Price AS DECIMAL(10, 0))) AS TotalPrice FROM Bookings;").ToString();
            List<(string, string, string, DateTime)> bookingsData = GetBookingsData(0);
            List<(string, string, string, DateTime)> bookingsData1 = GetBookingsData(1);
            List<(string, string, string, DateTime)> bookingsData2 = GetBookingsData(2);

            this.labelRecentName.Text = bookingsData[0].Item1;
            this.labelNum.Text = bookingsData[0].Item2;
            this.labelpayment.Text = bookingsData[0].Item3;
            this.labelCheckin.Text = bookingsData[0].Item4.ToString();

            this.labelRecentName1.Text = bookingsData1[0].Item1;
            this.labelNum1.Text = bookingsData1[0].Item2;
            this.labelpayment1.Text = bookingsData1[0].Item3;
            this.labelCheckin1.Text = bookingsData1[0].Item4.ToString();

            this.labelRecentName2.Text = bookingsData2[0].Item1;
            this.labelNum2.Text = bookingsData2[0].Item2;
            this.labelpayment2.Text = bookingsData2[0].Item3;
            this.labelCheckin2.Text = bookingsData2[0].Item4.ToString();


        }
    }
}
