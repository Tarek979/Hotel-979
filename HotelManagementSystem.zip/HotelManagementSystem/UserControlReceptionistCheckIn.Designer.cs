﻿namespace HotelManagementSystem
{
    partial class UserControlReceptionistCheckIn
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxAddressValue = new System.Windows.Forms.TextBox();
            this.textBoxPhoneValue = new System.Windows.Forms.TextBox();
            this.textBoxEmailValue = new System.Windows.Forms.TextBox();
            this.textBoxCNameValue = new System.Windows.Forms.TextBox();
            this.textBoxCusIDValue = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.buttonCheckin = new System.Windows.Forms.Button();
            this.dgvReservation = new System.Windows.Forms.DataGridView();
            this.ReservationId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RoomId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CheckInDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CheckOutDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBoxGenderValue = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservation)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Guest Info";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 247);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 13);
            this.label8.TabIndex = 69;
            this.label8.Text = "Address";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 216);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 68;
            this.label7.Text = "Phone";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 67;
            this.label6.Text = "Email";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 130);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 66;
            this.label5.Text = "Customer Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 65;
            this.label4.Text = "Customer ID";
            // 
            // textBoxAddressValue
            // 
            this.textBoxAddressValue.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAddressValue.Location = new System.Drawing.Point(114, 244);
            this.textBoxAddressValue.Name = "textBoxAddressValue";
            this.textBoxAddressValue.Size = new System.Drawing.Size(163, 20);
            this.textBoxAddressValue.TabIndex = 64;
            // 
            // textBoxPhoneValue
            // 
            this.textBoxPhoneValue.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxPhoneValue.Location = new System.Drawing.Point(114, 216);
            this.textBoxPhoneValue.Name = "textBoxPhoneValue";
            this.textBoxPhoneValue.Size = new System.Drawing.Size(163, 20);
            this.textBoxPhoneValue.TabIndex = 63;
            // 
            // textBoxEmailValue
            // 
            this.textBoxEmailValue.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxEmailValue.Location = new System.Drawing.Point(114, 188);
            this.textBoxEmailValue.Name = "textBoxEmailValue";
            this.textBoxEmailValue.Size = new System.Drawing.Size(163, 20);
            this.textBoxEmailValue.TabIndex = 62;
            // 
            // textBoxCNameValue
            // 
            this.textBoxCNameValue.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxCNameValue.Location = new System.Drawing.Point(114, 127);
            this.textBoxCNameValue.Name = "textBoxCNameValue";
            this.textBoxCNameValue.Size = new System.Drawing.Size(163, 20);
            this.textBoxCNameValue.TabIndex = 61;
            // 
            // textBoxCusIDValue
            // 
            this.textBoxCusIDValue.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxCusIDValue.Location = new System.Drawing.Point(114, 88);
            this.textBoxCusIDValue.Name = "textBoxCusIDValue";
            this.textBoxCusIDValue.Size = new System.Drawing.Size(163, 20);
            this.textBoxCusIDValue.TabIndex = 60;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(610, 232);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 79;
            this.label3.Text = "Price";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(610, 193);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 13);
            this.label9.TabIndex = 78;
            this.label9.Text = "Room Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(610, 154);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 13);
            this.label10.TabIndex = 77;
            this.label10.Text = "Room Number";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(610, 115);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 76;
            this.label11.Text = "Room ID";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox7.Location = new System.Drawing.Point(703, 229);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(163, 20);
            this.textBox7.TabIndex = 74;
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox8.Location = new System.Drawing.Point(703, 190);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(163, 20);
            this.textBox8.TabIndex = 73;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox9.Location = new System.Drawing.Point(703, 151);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(163, 20);
            this.textBox9.TabIndex = 72;
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox10.Location = new System.Drawing.Point(703, 112);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(163, 20);
            this.textBox10.TabIndex = 71;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(606, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 39);
            this.label12.TabIndex = 70;
            this.label12.Text = "Room Info";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(24, 42);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(253, 31);
            this.button2.TabIndex = 81;
            this.button2.Text = "Select Guest";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(613, 71);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(253, 31);
            this.button3.TabIndex = 82;
            this.button3.Text = "Select Room";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(313, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 90;
            this.label2.Text = "Payment Method";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(313, 160);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 13);
            this.label13.TabIndex = 89;
            this.label13.Text = "PaymentDate";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(319, 122);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 88;
            this.label14.Text = "BookingId";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(319, 83);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 87;
            this.label15.Text = "PaymentId";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox1.Location = new System.Drawing.Point(406, 196);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(163, 20);
            this.textBox1.TabIndex = 86;
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox11.Location = new System.Drawing.Point(406, 157);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(163, 20);
            this.textBox11.TabIndex = 85;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox12.Location = new System.Drawing.Point(406, 118);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(163, 20);
            this.textBox12.TabIndex = 84;
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox13.Location = new System.Drawing.Point(406, 79);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(163, 20);
            this.textBox13.TabIndex = 83;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Calibri", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(309, 26);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(193, 39);
            this.label16.TabIndex = 91;
            this.label16.Text = "Payment Info";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(313, 235);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 13);
            this.label17.TabIndex = 93;
            this.label17.Text = "Payment Amount";
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBox14.Location = new System.Drawing.Point(406, 232);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(163, 20);
            this.textBox14.TabIndex = 92;
            // 
            // buttonCheckin
            // 
            this.buttonCheckin.BackColor = System.Drawing.Color.DarkGreen;
            this.buttonCheckin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCheckin.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCheckin.ForeColor = System.Drawing.Color.White;
            this.buttonCheckin.Location = new System.Drawing.Point(740, 483);
            this.buttonCheckin.Name = "buttonCheckin";
            this.buttonCheckin.Size = new System.Drawing.Size(165, 57);
            this.buttonCheckin.TabIndex = 94;
            this.buttonCheckin.Text = "Check-In";
            this.buttonCheckin.UseVisualStyleBackColor = false;
            // 
            // dgvReservation
            // 
            this.dgvReservation.AllowUserToAddRows = false;
            this.dgvReservation.AllowUserToDeleteRows = false;
            this.dgvReservation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReservation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ReservationId,
            this.RoomId,
            this.CustomerId,
            this.CustomerNumber,
            this.CheckInDate,
            this.CheckOutDate,
            this.Status});
            this.dgvReservation.Location = new System.Drawing.Point(19, 303);
            this.dgvReservation.Name = "dgvReservation";
            this.dgvReservation.ReadOnly = true;
            this.dgvReservation.Size = new System.Drawing.Size(715, 237);
            this.dgvReservation.TabIndex = 95;
            // 
            // ReservationId
            // 
            this.ReservationId.DataPropertyName = "ReservationId";
            this.ReservationId.HeaderText = "ReservationId";
            this.ReservationId.Name = "ReservationId";
            this.ReservationId.ReadOnly = true;
            // 
            // RoomId
            // 
            this.RoomId.DataPropertyName = "RoomId";
            this.RoomId.HeaderText = "RoomId";
            this.RoomId.Name = "RoomId";
            this.RoomId.ReadOnly = true;
            // 
            // CustomerId
            // 
            this.CustomerId.DataPropertyName = "CustomerId";
            this.CustomerId.HeaderText = "CustomerId";
            this.CustomerId.Name = "CustomerId";
            this.CustomerId.ReadOnly = true;
            // 
            // CustomerNumber
            // 
            this.CustomerNumber.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CustomerNumber.DataPropertyName = "CustomerNumber";
            this.CustomerNumber.HeaderText = "CustomerNumber";
            this.CustomerNumber.Name = "CustomerNumber";
            this.CustomerNumber.ReadOnly = true;
            // 
            // CheckInDate
            // 
            this.CheckInDate.DataPropertyName = "CheckInDate";
            this.CheckInDate.HeaderText = "CheckInDate";
            this.CheckInDate.Name = "CheckInDate";
            this.CheckInDate.ReadOnly = true;
            // 
            // CheckOutDate
            // 
            this.CheckOutDate.DataPropertyName = "CheckOutDate";
            this.CheckOutDate.HeaderText = "CheckOutDate";
            this.CheckOutDate.Name = "CheckOutDate";
            this.CheckOutDate.ReadOnly = true;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(18, 266);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(327, 33);
            this.label18.TabIndex = 96;
            this.label18.Text = "Check-In From Reservation  ";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(21, 164);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 13);
            this.label19.TabIndex = 97;
            this.label19.Text = "Gender";
            // 
            // comboBoxGenderValue
            // 
            this.comboBoxGenderValue.FormattingEnabled = true;
            this.comboBoxGenderValue.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Others"});
            this.comboBoxGenderValue.Location = new System.Drawing.Point(114, 160);
            this.comboBoxGenderValue.Name = "comboBoxGenderValue";
            this.comboBoxGenderValue.Size = new System.Drawing.Size(163, 21);
            this.comboBoxGenderValue.TabIndex = 98;
            // 
            // UserControlReceptionistCheckIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.comboBoxGenderValue);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.dgvReservation);
            this.Controls.Add(this.buttonCheckin);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxAddressValue);
            this.Controls.Add(this.textBoxPhoneValue);
            this.Controls.Add(this.textBoxEmailValue);
            this.Controls.Add(this.textBoxCNameValue);
            this.Controls.Add(this.textBoxCusIDValue);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "UserControlReceptionistCheckIn";
            this.Size = new System.Drawing.Size(912, 550);
            this.Load += new System.EventHandler(this.UserControlReceptionistCheckIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReservation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxAddressValue;
        private System.Windows.Forms.TextBox textBoxPhoneValue;
        private System.Windows.Forms.TextBox textBoxEmailValue;
        private System.Windows.Forms.TextBox textBoxCNameValue;
        private System.Windows.Forms.TextBox textBoxCusIDValue;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Button buttonCheckin;
        private System.Windows.Forms.DataGridView dgvReservation;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReservationId;
        private System.Windows.Forms.DataGridViewTextBoxColumn RoomId;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerId;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn CheckInDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CheckOutDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBoxGenderValue;
    }
}
