﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlReceptionistManageReservations : UserControl
    {
        private CurdOperations co = new CurdOperations();
        public UserControlReceptionistManageReservations()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvReservations, "select * from Reservation;");
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.co.SearchData(this.dgvReservations, "select * from Reservation where ReservationId='" + textBoxSearch.Text + "';   ");
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            this.textBoxResID.Text = this.dgvReservations.CurrentRow.Cells[0].Value.ToString();
            this.textBoxRoomID.Text = this.dgvReservations.CurrentRow.Cells[1].Value.ToString();
            this.textBoxCustomerID.Text = this.dgvReservations.CurrentRow.Cells[2].Value.ToString();
            this.textBoxCName.Text = this.dgvReservations.CurrentRow.Cells[3].Value.ToString();
            this.textBoxCheckIn.Text = this.dgvReservations.CurrentRow.Cells[4].Value.ToString();
            this.textBoxCheckOut.Text = this.dgvReservations.CurrentRow.Cells[5].Value.ToString();
            this.textBoxStatus.Text = this.dgvReservations.CurrentRow.Cells[6].Value.ToString();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            this.co.DeleteData(this.dgvReservations, "Reservation", "ReservationId");
            this.co.loadGridView(this.dgvReservations, "select * from Reservation;");
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool isValid = IsValidToSave();
            var query = "select * from Reservation where ReservationId = '" + this.textBoxResID.Text + "'";
            var sqlUpdate = @"update Reservation
                      set RoomId = '" + this.textBoxRoomID.Text + @"',
                      CustomerId = '" + this.textBoxCustomerID.Text + @"',
                      CheckInDate = '" + this.textBoxCheckIn.Text + @"',
                      CheckOutDate = '" + this.textBoxCheckOut.Text + @"',
                      Status = '" + this.textBoxStatus.Text + @"',
                      CustomerNumber = '" + this.textBoxCName.Text + @"'
                      where ReservationId = '" + this.textBoxResID.Text + "';";
            var sqlInsert = "insert into Reservation values('" + this.textBoxResID.Text + "', '" + this.textBoxRoomID.Text + "', '" + this.textBoxCustomerID.Text + "', '" + this.textBoxCheckIn.Text + "', '" + this.textBoxCheckOut.Text + "', '" + this.textBoxStatus.Text + "', '" + this.textBoxCName.Text + "'); ";


            this.co.SaveData(query, sqlUpdate, sqlInsert, isValid);
            this.co.loadGridView(this.dgvReservations, "select * from Reservation;");
        }

        private bool IsValidToSave()
        {
            if (string.IsNullOrWhiteSpace(this.textBoxResID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxRoomID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCustomerID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCName.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCheckIn.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCheckOut.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxStatus.Text))
            {
                MessageBox.Show("Please fill up all the values");
                return false;
            }
            return true;
        }
    }
}
