﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlReceptionistCheckIn : UserControl
    {
        public void SetCustomerData(string cusID, string cName, string gender, string email, string phone, string address)
        {
            this.textBoxCusIDValue.Text = cusID;
            this.textBoxCNameValue.Text = cName;
            this.comboBoxGenderValue.Text = gender;
            this.textBoxEmailValue.Text = email;
            this.textBoxPhoneValue.Text = phone;
            this.textBoxAddressValue.Text = address;
        }

        private CurdOperations co = new CurdOperations();
        public UserControlReceptionistCheckIn()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvReservation, "select * from Reservation;");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormSelectCustomerData fc= new FormSelectCustomerData();
            fc.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void UserControlReceptionistCheckIn_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormSelectRoomData fr = new FormSelectRoomData();
            fr.Visible = true;
        }
    }
}
