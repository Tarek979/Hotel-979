﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    
    public partial class FormSelectCustomerData : Form
    {
        private CurdOperations co = new CurdOperations();

        public CurdOperations Co { get => co; set => co = value; }

        public FormSelectCustomerData()
        {
            InitializeComponent();
        }

        private void FormSelectData_Load(object sender, EventArgs e)
        {
            this.Co.loadGridView(this.dgvCustomers, "select * from Customers;");
        }

        private void dgvCustomers_DoubleClick(object sender, EventArgs e)
        {

            UserControlReceptionistCheckIn userControlReceptionistCheckIn = new UserControlReceptionistCheckIn();
            userControlReceptionistCheckIn.SetCustomerData(
        this.dgvCustomers.CurrentRow.Cells[0].Value.ToString(),
        this.dgvCustomers.CurrentRow.Cells[1].Value.ToString(),
        this.dgvCustomers.CurrentRow.Cells[2].Value.ToString(),
        this.dgvCustomers.CurrentRow.Cells[3].Value.ToString(),
        this.dgvCustomers.CurrentRow.Cells[4].Value.ToString(),
        this.dgvCustomers.CurrentRow.Cells[5].Value.ToString()
    );
            this.Close();
        }
    }
}
