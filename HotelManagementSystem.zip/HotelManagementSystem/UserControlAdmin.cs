﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlAdmin : UserControl
    {
        private UserControl current;
        private void navigateScreens(UserControl uc)
        {
            this.groupBoxAdminUserControlls.Controls.Remove(current);
            this.current = uc;
            this.groupBoxAdminUserControlls.Controls.Add(current);
        }
        private void changeTextAndColor(Button Button)
        {
            this.labelAdminHeader.Text=Button.Text;
            this.panelTopBar.BackColor = Button.BackColor;
           
        }
        private void signOut()
        {
            UserControlLogin ucLogin = new UserControlLogin();
            FormMain fromm = (FormMain)this.ParentForm;
            fromm.panelMain.Controls.Remove(this);
            fromm.panelMain.Controls.Add(ucLogin);
        }
        public UserControlAdmin()
        {
            InitializeComponent();
            UserControlAdminDashboard ucad=  new UserControlAdminDashboard ();
            current= ucad;
            this.groupBoxAdminUserControlls.Controls.Add(current); 
        }

        private void buttonDashBoard_Click(object sender, EventArgs e)
        {
            UserControlAdminDashboard ucad = new UserControlAdminDashboard();
            this.changeTextAndColor(buttonDashBoard);
            this.navigateScreens(ucad);
           
        }

        private void buttonEmployee_Click(object sender, EventArgs e)
        {
            UserControlAdminManageEmployee ucame = new UserControlAdminManageEmployee();
            this.changeTextAndColor(buttonEmployee);
            this.navigateScreens (ucame);
        }

        private void buttonRooms_Click(object sender, EventArgs e)
        {
            UserControlAdminManageRoom ucamr = new UserControlAdminManageRoom();
            this.changeTextAndColor (buttonRooms);
            this.navigateScreens(ucamr);

        }

        private void buttonBookList_Click(object sender, EventArgs e)
        {
            UserControlAdminBooklist ucamb = new UserControlAdminBooklist();
            this.changeTextAndColor(buttonBookList);
            this.navigateScreens(ucamb);
        }

        private void labelSignout_Click(object sender, EventArgs e)
        {
            this.signOut();
           
        }

        private void pictureBoxSignout_Click(object sender, EventArgs e)
        {
            this.signOut();
        }
    }
}
