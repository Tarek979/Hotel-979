﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlAdminBooklist : UserControl
    {
        private CurdOperations co = new CurdOperations();
        private DataAccess da = new DataAccess();
       
        private int GetRowCount(string query = "select * from Bookings;")
        {

            var dt = this.da.ExecuteQueryTable(query);
            int rows = dt.Rows.Count;
            return rows;
            
        }
        private string GetSum(string query = "SELECT SUM(CAST(Price AS DECIMAL(10, 2))) AS TotalPrice FROM Bookings;")
        {

            var dt = this.da.ExecuteQueryTable(query);
            string sum = "$";
            sum += dt.Rows[0][0].ToString();
            return (sum);

        }

        public UserControlAdminBooklist()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvBooking, "select * from Bookings;");
        }

        private void UserControlAdminBooklist_Load(object sender, EventArgs e)
        {
           
            this.labelPayemntPendingNumber.Text=GetRowCount("select * from Bookings where PaymentStatus!='paid';").ToString();
            this.labelBookedNumber.Text = GetRowCount("select * from Bookings").ToString();
            this.labelIncomeNumber.Text = GetSum("SELECT SUM(CAST(Price AS DECIMAL(10, 0))) AS TotalPrice FROM Bookings;").ToString();

        }

       
    }
}
