﻿namespace HotelManagementSystem
{
    partial class UserControlReceptionistManageBookings
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.dgvBooking = new System.Windows.Forms.DataGridView();
            this.labelSearch = new System.Windows.Forms.Label();
            this.labelBookingTitle = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxCusID = new System.Windows.Forms.TextBox();
            this.textBoxRNum = new System.Windows.Forms.TextBox();
            this.textBoxRoomID = new System.Windows.Forms.TextBox();
            this.textBoxBookID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.textBoxCheckOut = new System.Windows.Forms.TextBox();
            this.textBoxCheckIn = new System.Windows.Forms.TextBox();
            this.textBoxCusName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxPaymentStatus = new System.Windows.Forms.TextBox();
            this.textBoxPayemntID = new System.Windows.Forms.TextBox();
            this.buttonEdit = new System.Windows.Forms.Button();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonSave = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxCusNum = new System.Windows.Forms.TextBox();
            this.ReceptionistID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RoomId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RoomNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CheckInDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CheckOutDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Phone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PaymentId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooking)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(17, 71);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(725, 20);
            this.textBoxSearch.TabIndex = 50;
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonSearch.FlatAppearance.BorderSize = 0;
            this.buttonSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSearch.ForeColor = System.Drawing.Color.White;
            this.buttonSearch.Location = new System.Drawing.Point(748, 68);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(130, 27);
            this.buttonSearch.TabIndex = 49;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // dgvBooking
            // 
            this.dgvBooking.AllowUserToAddRows = false;
            this.dgvBooking.AllowUserToDeleteRows = false;
            this.dgvBooking.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBooking.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ReceptionistID,
            this.RoomId,
            this.CustomerID,
            this.UserName,
            this.RoomNumber,
            this.CheckInDate,
            this.CheckOutDate,
            this.Price,
            this.PaymentStatus,
            this.Phone,
            this.PaymentId});
            this.dgvBooking.Location = new System.Drawing.Point(17, 101);
            this.dgvBooking.Name = "dgvBooking";
            this.dgvBooking.ReadOnly = true;
            this.dgvBooking.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvBooking.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBooking.Size = new System.Drawing.Size(857, 273);
            this.dgvBooking.TabIndex = 47;
            // 
            // labelSearch
            // 
            this.labelSearch.AutoSize = true;
            this.labelSearch.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSearch.Location = new System.Drawing.Point(13, 45);
            this.labelSearch.Name = "labelSearch";
            this.labelSearch.Size = new System.Drawing.Size(115, 19);
            this.labelSearch.TabIndex = 48;
            this.labelSearch.Text = "Search Bookings";
            // 
            // labelBookingTitle
            // 
            this.labelBookingTitle.AutoSize = true;
            this.labelBookingTitle.Font = new System.Drawing.Font("Calibri", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBookingTitle.Location = new System.Drawing.Point(7, 3);
            this.labelBookingTitle.Name = "labelBookingTitle";
            this.labelBookingTitle.Size = new System.Drawing.Size(294, 45);
            this.labelBookingTitle.TabIndex = 46;
            this.labelBookingTitle.Text = "Manage Bookings";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 501);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 87;
            this.label7.Text = "Customer ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 462);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 86;
            this.label6.Text = "Room Number";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 423);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 85;
            this.label5.Text = "Room ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 384);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 84;
            this.label4.Text = "Booking ID";
            // 
            // textBoxCusID
            // 
            this.textBoxCusID.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxCusID.Location = new System.Drawing.Point(20, 517);
            this.textBoxCusID.Name = "textBoxCusID";
            this.textBoxCusID.Size = new System.Drawing.Size(163, 20);
            this.textBoxCusID.TabIndex = 82;
            // 
            // textBoxRNum
            // 
            this.textBoxRNum.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxRNum.Location = new System.Drawing.Point(20, 478);
            this.textBoxRNum.Name = "textBoxRNum";
            this.textBoxRNum.Size = new System.Drawing.Size(163, 20);
            this.textBoxRNum.TabIndex = 81;
            // 
            // textBoxRoomID
            // 
            this.textBoxRoomID.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxRoomID.Location = new System.Drawing.Point(20, 439);
            this.textBoxRoomID.Name = "textBoxRoomID";
            this.textBoxRoomID.Size = new System.Drawing.Size(163, 20);
            this.textBoxRoomID.TabIndex = 80;
            // 
            // textBoxBookID
            // 
            this.textBoxBookID.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxBookID.Location = new System.Drawing.Point(20, 400);
            this.textBoxBookID.Name = "textBoxBookID";
            this.textBoxBookID.Size = new System.Drawing.Size(163, 20);
            this.textBoxBookID.TabIndex = 79;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(205, 501);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 95;
            this.label1.Text = "Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(205, 462);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 94;
            this.label2.Text = "Check-Out Date";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(205, 423);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 93;
            this.label3.Text = "Check-In Date";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(205, 384);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 13);
            this.label8.TabIndex = 92;
            this.label8.Text = "Customer Number";
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxPrice.Location = new System.Drawing.Point(208, 517);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(163, 20);
            this.textBoxPrice.TabIndex = 91;
            // 
            // textBoxCheckOut
            // 
            this.textBoxCheckOut.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxCheckOut.Location = new System.Drawing.Point(208, 478);
            this.textBoxCheckOut.Name = "textBoxCheckOut";
            this.textBoxCheckOut.Size = new System.Drawing.Size(163, 20);
            this.textBoxCheckOut.TabIndex = 90;
            // 
            // textBoxCheckIn
            // 
            this.textBoxCheckIn.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxCheckIn.Location = new System.Drawing.Point(208, 439);
            this.textBoxCheckIn.Name = "textBoxCheckIn";
            this.textBoxCheckIn.Size = new System.Drawing.Size(163, 20);
            this.textBoxCheckIn.TabIndex = 89;
            // 
            // textBoxCusName
            // 
            this.textBoxCusName.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxCusName.Location = new System.Drawing.Point(208, 400);
            this.textBoxCusName.Name = "textBoxCusName";
            this.textBoxCusName.Size = new System.Drawing.Size(163, 20);
            this.textBoxCusName.TabIndex = 88;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(386, 383);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 13);
            this.label11.TabIndex = 101;
            this.label11.Text = "Payemnt Status";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(386, 462);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 13);
            this.label12.TabIndex = 100;
            this.label12.Text = "Payment ID";
            // 
            // textBoxPaymentStatus
            // 
            this.textBoxPaymentStatus.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxPaymentStatus.Location = new System.Drawing.Point(389, 399);
            this.textBoxPaymentStatus.Name = "textBoxPaymentStatus";
            this.textBoxPaymentStatus.Size = new System.Drawing.Size(163, 20);
            this.textBoxPaymentStatus.TabIndex = 97;
            // 
            // textBoxPayemntID
            // 
            this.textBoxPayemntID.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxPayemntID.Location = new System.Drawing.Point(389, 478);
            this.textBoxPayemntID.Name = "textBoxPayemntID";
            this.textBoxPayemntID.Size = new System.Drawing.Size(163, 20);
            this.textBoxPayemntID.TabIndex = 96;
            // 
            // buttonEdit
            // 
            this.buttonEdit.BackColor = System.Drawing.Color.DodgerBlue;
            this.buttonEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEdit.ForeColor = System.Drawing.Color.White;
            this.buttonEdit.Location = new System.Drawing.Point(748, 452);
            this.buttonEdit.Name = "buttonEdit";
            this.buttonEdit.Size = new System.Drawing.Size(126, 33);
            this.buttonEdit.TabIndex = 106;
            this.buttonEdit.Text = "Edit";
            this.buttonEdit.UseVisualStyleBackColor = false;
            this.buttonEdit.Click += new System.EventHandler(this.buttonEdit_Click);
            // 
            // buttonDelete
            // 
            this.buttonDelete.BackColor = System.Drawing.Color.Red;
            this.buttonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDelete.ForeColor = System.Drawing.Color.White;
            this.buttonDelete.Location = new System.Drawing.Point(748, 491);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(126, 33);
            this.buttonDelete.TabIndex = 104;
            this.buttonDelete.Text = "Delete";
            this.buttonDelete.UseVisualStyleBackColor = false;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonSave
            // 
            this.buttonSave.BackColor = System.Drawing.Color.SeaGreen;
            this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSave.ForeColor = System.Drawing.Color.White;
            this.buttonSave.Location = new System.Drawing.Point(748, 413);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(126, 33);
            this.buttonSave.TabIndex = 105;
            this.buttonSave.Text = "Save";
            this.buttonSave.UseVisualStyleBackColor = false;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(388, 423);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 13);
            this.label9.TabIndex = 108;
            this.label9.Text = "CustomerNumber";
            // 
            // textBoxCusNum
            // 
            this.textBoxCusNum.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxCusNum.Location = new System.Drawing.Point(391, 439);
            this.textBoxCusNum.Name = "textBoxCusNum";
            this.textBoxCusNum.Size = new System.Drawing.Size(163, 20);
            this.textBoxCusNum.TabIndex = 107;
            // 
            // ReceptionistID
            // 
            this.ReceptionistID.DataPropertyName = "BookingId";
            this.ReceptionistID.HeaderText = "BookingId";
            this.ReceptionistID.Name = "ReceptionistID";
            this.ReceptionistID.ReadOnly = true;
            this.ReceptionistID.Width = 70;
            // 
            // RoomId
            // 
            this.RoomId.DataPropertyName = "RoomId";
            this.RoomId.HeaderText = "RoomId";
            this.RoomId.Name = "RoomId";
            this.RoomId.ReadOnly = true;
            this.RoomId.Width = 70;
            // 
            // CustomerID
            // 
            this.CustomerID.DataPropertyName = "CustomerID";
            this.CustomerID.HeaderText = "CustomerID";
            this.CustomerID.Name = "CustomerID";
            this.CustomerID.ReadOnly = true;
            this.CustomerID.Width = 70;
            // 
            // UserName
            // 
            this.UserName.DataPropertyName = "CustomerName";
            this.UserName.HeaderText = "Customer Name";
            this.UserName.Name = "UserName";
            this.UserName.ReadOnly = true;
            // 
            // RoomNumber
            // 
            this.RoomNumber.DataPropertyName = "RoomNumber";
            this.RoomNumber.HeaderText = "Room Number";
            this.RoomNumber.Name = "RoomNumber";
            this.RoomNumber.ReadOnly = true;
            this.RoomNumber.Width = 70;
            // 
            // CheckInDate
            // 
            this.CheckInDate.DataPropertyName = "CheckInDate";
            this.CheckInDate.HeaderText = "Check-in";
            this.CheckInDate.Name = "CheckInDate";
            this.CheckInDate.ReadOnly = true;
            this.CheckInDate.Width = 70;
            // 
            // CheckOutDate
            // 
            this.CheckOutDate.DataPropertyName = "CheckOutDate";
            this.CheckOutDate.HeaderText = "Check-out";
            this.CheckOutDate.Name = "CheckOutDate";
            this.CheckOutDate.ReadOnly = true;
            this.CheckOutDate.Width = 70;
            // 
            // Price
            // 
            this.Price.DataPropertyName = "Price";
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.ReadOnly = true;
            this.Price.Width = 80;
            // 
            // PaymentStatus
            // 
            this.PaymentStatus.DataPropertyName = "PaymentStatus";
            this.PaymentStatus.HeaderText = "Payment Status";
            this.PaymentStatus.Name = "PaymentStatus";
            this.PaymentStatus.ReadOnly = true;
            this.PaymentStatus.Width = 70;
            // 
            // Phone
            // 
            this.Phone.DataPropertyName = "CustomerNumber";
            this.Phone.HeaderText = "Customer Number";
            this.Phone.Name = "Phone";
            this.Phone.ReadOnly = true;
            this.Phone.Width = 80;
            // 
            // PaymentId
            // 
            this.PaymentId.DataPropertyName = "PaymentId";
            this.PaymentId.HeaderText = "PaymentId";
            this.PaymentId.Name = "PaymentId";
            this.PaymentId.ReadOnly = true;
            this.PaymentId.Width = 70;
            // 
            // UserControlReceptionistManageBookings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxCusNum);
            this.Controls.Add(this.buttonEdit);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBoxPaymentStatus);
            this.Controls.Add(this.textBoxPayemntID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxPrice);
            this.Controls.Add(this.textBoxCheckOut);
            this.Controls.Add(this.textBoxCheckIn);
            this.Controls.Add(this.textBoxCusName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxCusID);
            this.Controls.Add(this.textBoxRNum);
            this.Controls.Add(this.textBoxRoomID);
            this.Controls.Add(this.textBoxBookID);
            this.Controls.Add(this.textBoxSearch);
            this.Controls.Add(this.buttonSearch);
            this.Controls.Add(this.dgvBooking);
            this.Controls.Add(this.labelSearch);
            this.Controls.Add(this.labelBookingTitle);
            this.Name = "UserControlReceptionistManageBookings";
            this.Size = new System.Drawing.Size(912, 550);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBooking)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.DataGridView dgvBooking;
        private System.Windows.Forms.Label labelSearch;
        private System.Windows.Forms.Label labelBookingTitle;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxCusID;
        private System.Windows.Forms.TextBox textBoxRNum;
        private System.Windows.Forms.TextBox textBoxRoomID;
        private System.Windows.Forms.TextBox textBoxBookID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxCheckOut;
        private System.Windows.Forms.TextBox textBoxCheckIn;
        private System.Windows.Forms.TextBox textBoxCusName;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxPaymentStatus;
        private System.Windows.Forms.TextBox textBoxPayemntID;
        private System.Windows.Forms.Button buttonEdit;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxCusNum;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReceptionistID;
        private System.Windows.Forms.DataGridViewTextBoxColumn RoomId;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserName;
        private System.Windows.Forms.DataGridViewTextBoxColumn RoomNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn CheckInDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn CheckOutDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn Phone;
        private System.Windows.Forms.DataGridViewTextBoxColumn PaymentId;
    }
}
