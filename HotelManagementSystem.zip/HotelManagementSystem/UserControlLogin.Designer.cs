﻿namespace HotelManagementSystem
{
    partial class UserControlLogin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlLogin));
            this.panelLogin = new System.Windows.Forms.Panel();
            this.buttonEye = new System.Windows.Forms.Button();
            this.lblWelcomeText = new System.Windows.Forms.Label();
            this.lblSignIn = new System.Windows.Forms.Label();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.textBoxUID = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBoxWelcomePage = new System.Windows.Forms.GroupBox();
            this.panelLogin.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelLogin
            // 
            this.panelLogin.BackColor = System.Drawing.Color.White;
            this.panelLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panelLogin.Controls.Add(this.buttonEye);
            this.panelLogin.Controls.Add(this.lblWelcomeText);
            this.panelLogin.Controls.Add(this.lblSignIn);
            this.panelLogin.Controls.Add(this.textBoxPassword);
            this.panelLogin.Controls.Add(this.textBoxUID);
            this.panelLogin.Controls.Add(this.btnLogin);
            this.panelLogin.Controls.Add(this.lblPassword);
            this.panelLogin.Controls.Add(this.lblUserID);
            this.panelLogin.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelLogin.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelLogin.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelLogin.Location = new System.Drawing.Point(1028, 0);
            this.panelLogin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelLogin.Name = "panelLogin";
            this.panelLogin.Size = new System.Drawing.Size(528, 773);
            this.panelLogin.TabIndex = 0;
            // 
            // buttonEye
            // 
            this.buttonEye.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonEye.BackgroundImage")));
            this.buttonEye.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonEye.FlatAppearance.BorderSize = 0;
            this.buttonEye.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEye.Location = new System.Drawing.Point(457, 389);
            this.buttonEye.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonEye.Name = "buttonEye";
            this.buttonEye.Size = new System.Drawing.Size(32, 25);
            this.buttonEye.TabIndex = 8;
            this.buttonEye.UseVisualStyleBackColor = true;
            this.buttonEye.Click += new System.EventHandler(this.buttonEye_Click);
            // 
            // lblWelcomeText
            // 
            this.lblWelcomeText.AutoSize = true;
            this.lblWelcomeText.BackColor = System.Drawing.Color.White;
            this.lblWelcomeText.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcomeText.ForeColor = System.Drawing.Color.Black;
            this.lblWelcomeText.Location = new System.Drawing.Point(76, 210);
            this.lblWelcomeText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWelcomeText.Name = "lblWelcomeText";
            this.lblWelcomeText.Size = new System.Drawing.Size(190, 41);
            this.lblWelcomeText.TabIndex = 7;
            this.lblWelcomeText.Text = "Hello There!";
            // 
            // lblSignIn
            // 
            this.lblSignIn.AutoSize = true;
            this.lblSignIn.BackColor = System.Drawing.Color.White;
            this.lblSignIn.ForeColor = System.Drawing.Color.Black;
            this.lblSignIn.Location = new System.Drawing.Point(79, 267);
            this.lblSignIn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSignIn.Name = "lblSignIn";
            this.lblSignIn.Size = new System.Drawing.Size(235, 24);
            this.lblSignIn.TabIndex = 6;
            this.lblSignIn.Text = "Sign In bellow to Continue.";
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.BackColor = System.Drawing.Color.LightGray;
            this.textBoxPassword.Location = new System.Drawing.Point(192, 385);
            this.textBoxPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.PasswordChar = '*';
            this.textBoxPassword.Size = new System.Drawing.Size(256, 32);
            this.textBoxPassword.TabIndex = 4;
            // 
            // textBoxUID
            // 
            this.textBoxUID.BackColor = System.Drawing.Color.LightGray;
            this.textBoxUID.Location = new System.Drawing.Point(192, 329);
            this.textBoxUID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBoxUID.Name = "textBoxUID";
            this.textBoxUID.Size = new System.Drawing.Size(256, 32);
            this.textBoxUID.TabIndex = 3;
            this.textBoxUID.TextChanged += new System.EventHandler(this.textBoxUID_TextChanged);
            // 
            // btnLogin
            // 
            this.btnLogin.BackColor = System.Drawing.Color.Black;
            this.btnLogin.FlatAppearance.BorderSize = 0;
            this.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogin.ForeColor = System.Drawing.Color.White;
            this.btnLogin.Location = new System.Drawing.Point(85, 442);
            this.btnLogin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(364, 42);
            this.btnLogin.TabIndex = 2;
            this.btnLogin.Text = "Sign In";
            this.btnLogin.UseVisualStyleBackColor = false;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.ForeColor = System.Drawing.Color.Black;
            this.lblPassword.Location = new System.Drawing.Point(80, 390);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(89, 24);
            this.lblPassword.TabIndex = 1;
            this.lblPassword.Text = "Password";
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserID.ForeColor = System.Drawing.Color.Black;
            this.lblUserID.Location = new System.Drawing.Point(80, 332);
            this.lblUserID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(70, 24);
            this.lblUserID.TabIndex = 0;
            this.lblUserID.Text = "User ID";
            // 
            // panel1
            // 
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Controls.Add(this.groupBoxWelcomePage);
            this.panel1.Controls.Add(this.panelLogin);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1556, 773);
            this.panel1.TabIndex = 1;
            // 
            // groupBoxWelcomePage
            // 
            this.groupBoxWelcomePage.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.groupBoxWelcomePage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBoxWelcomePage.BackgroundImage")));
            this.groupBoxWelcomePage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBoxWelcomePage.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxWelcomePage.Location = new System.Drawing.Point(0, 0);
            this.groupBoxWelcomePage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxWelcomePage.Name = "groupBoxWelcomePage";
            this.groupBoxWelcomePage.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxWelcomePage.Size = new System.Drawing.Size(1028, 773);
            this.groupBoxWelcomePage.TabIndex = 1;
            this.groupBoxWelcomePage.TabStop = false;
            this.groupBoxWelcomePage.Enter += new System.EventHandler(this.groupBoxWelcomePage_Enter);
            // 
            // UserControlLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UserControlLogin";
            this.Size = new System.Drawing.Size(1556, 773);
            this.panelLogin.ResumeLayout(false);
            this.panelLogin.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogin;
        private System.Windows.Forms.Button buttonEye;
        private System.Windows.Forms.Label lblWelcomeText;
        private System.Windows.Forms.Label lblSignIn;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.TextBox textBoxUID;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBoxWelcomePage;
    }
}
