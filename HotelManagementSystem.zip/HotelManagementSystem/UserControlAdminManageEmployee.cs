﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlAdminManageEmployee : UserControl
    {
        private CurdOperations co = new CurdOperations();
        public UserControlAdminManageEmployee()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvReceptionist, "select * from Receptionists;");
           
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool isValid = IsValidToSave();
            var query = "select * from Receptionists where ReceptionistId = '" + this.textBoxRID.Text + "'";
            var sqlUpdate = @"update Receptionists
                      set Username = '" + this.textBoxUserName.Text + @"',
                      Password = '" + this.textBoxPassword.Text + @"',
                      FullName = '" + this.textBoxFullName.Text + @"',
                      Email = '" + this.textBoxEmail.Text + @"',
                      Phone = '" + this.textBoxNumber.Text + @"',
                      Address = '" + this.textBoxAddress.Text + @"'
                      where ReceptionistId = '" + this.textBoxRID.Text + "'; ";
            var sqlInsert = "insert into Receptionists values('" + this.textBoxRID.Text + "', '" + this.textBoxUserName.Text + "', '" + this.textBoxPassword.Text + "', '" + this.textBoxFullName.Text + "', '" + this.textBoxEmail.Text + "', '" + this.textBoxNumber.Text + "', '" + this.textBoxAddress.Text + "'); ";


            this.co.SaveData(query,sqlUpdate,sqlInsert,isValid);
            this.co.loadGridView(this.dgvReceptionist, "select * from Receptionists;");
        }

        private bool IsValidToSave()
        {
            if (string.IsNullOrWhiteSpace(this.textBoxRID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxUserName.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxPassword.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxEmail.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxNumber.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxAddress.Text))
            {
                MessageBox.Show("Please fill up all the values");
                return false;
            }
            return true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.co.DeleteData(this.dgvReceptionist,"Receptionists", "ReceptionistId");
            this.co.loadGridView(this.dgvReceptionist, "select * from Receptionists;");
          
        }

       

        private void button4_Click(object sender, EventArgs e)
        {
            this.textBoxRID.Text = this.dgvReceptionist.CurrentRow.Cells[0].Value.ToString();
            this.textBoxUserName.Text = this.dgvReceptionist.CurrentRow.Cells[1].Value.ToString();
            this.textBoxPassword.Text = this.dgvReceptionist.CurrentRow.Cells[2].Value.ToString();
            this.textBoxFullName.Text = this.dgvReceptionist.CurrentRow.Cells[3].Value.ToString();
            this.textBoxEmail.Text = this.dgvReceptionist.CurrentRow.Cells[4].Value.ToString();
            this.textBoxNumber.Text = this.dgvReceptionist.CurrentRow.Cells[5].Value.ToString();
            this.textBoxAddress.Text = this.dgvReceptionist.CurrentRow.Cells[6].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.co.SearchData(this.dgvReceptionist, "select * from Receptionists where ReceptionistId='" + textBoxSearch.Text + "';   ");

        }
    }
}
