﻿namespace HotelManagementSystem
{
    partial class UserControlAdmin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlAdmin));
            this.groupBoxAdminUserControlls = new System.Windows.Forms.GroupBox();
            this.panelTopBar = new System.Windows.Forms.Panel();
            this.labelSignout = new System.Windows.Forms.Label();
            this.pictureBoxSignout = new System.Windows.Forms.PictureBox();
            this.labelAdminHeader = new System.Windows.Forms.Label();
            this.panelSidebar = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelUserRoleName = new System.Windows.Forms.Label();
            this.buttonDashBoard = new System.Windows.Forms.Button();
            this.buttonRooms = new System.Windows.Forms.Button();
            this.buttonBookList = new System.Windows.Forms.Button();
            this.buttonEmployee = new System.Windows.Forms.Button();
            this.panelTopBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSignout)).BeginInit();
            this.panelSidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxAdminUserControlls
            // 
            this.groupBoxAdminUserControlls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxAdminUserControlls.Location = new System.Drawing.Point(340, 96);
            this.groupBoxAdminUserControlls.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxAdminUserControlls.Name = "groupBoxAdminUserControlls";
            this.groupBoxAdminUserControlls.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBoxAdminUserControlls.Size = new System.Drawing.Size(1216, 677);
            this.groupBoxAdminUserControlls.TabIndex = 5;
            this.groupBoxAdminUserControlls.TabStop = false;
            // 
            // panelTopBar
            // 
            this.panelTopBar.BackColor = System.Drawing.Color.Green;
            this.panelTopBar.Controls.Add(this.labelSignout);
            this.panelTopBar.Controls.Add(this.pictureBoxSignout);
            this.panelTopBar.Controls.Add(this.labelAdminHeader);
            this.panelTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTopBar.Location = new System.Drawing.Point(340, 0);
            this.panelTopBar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelTopBar.Name = "panelTopBar";
            this.panelTopBar.Size = new System.Drawing.Size(1216, 96);
            this.panelTopBar.TabIndex = 4;
            // 
            // labelSignout
            // 
            this.labelSignout.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelSignout.AutoSize = true;
            this.labelSignout.BackColor = System.Drawing.Color.Transparent;
            this.labelSignout.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSignout.ForeColor = System.Drawing.Color.White;
            this.labelSignout.Location = new System.Drawing.Point(1015, 27);
            this.labelSignout.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSignout.Name = "labelSignout";
            this.labelSignout.Size = new System.Drawing.Size(103, 33);
            this.labelSignout.TabIndex = 2;
            this.labelSignout.Text = "Sign out";
            this.labelSignout.Click += new System.EventHandler(this.labelSignout_Click);
            // 
            // pictureBoxSignout
            // 
            this.pictureBoxSignout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBoxSignout.BackgroundImage")));
            this.pictureBoxSignout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBoxSignout.Location = new System.Drawing.Point(1101, 17);
            this.pictureBoxSignout.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBoxSignout.Name = "pictureBoxSignout";
            this.pictureBoxSignout.Size = new System.Drawing.Size(91, 53);
            this.pictureBoxSignout.TabIndex = 1;
            this.pictureBoxSignout.TabStop = false;
            this.pictureBoxSignout.Click += new System.EventHandler(this.pictureBoxSignout_Click);
            // 
            // labelAdminHeader
            // 
            this.labelAdminHeader.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelAdminHeader.AutoSize = true;
            this.labelAdminHeader.BackColor = System.Drawing.Color.Transparent;
            this.labelAdminHeader.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdminHeader.ForeColor = System.Drawing.Color.White;
            this.labelAdminHeader.Location = new System.Drawing.Point(447, 26);
            this.labelAdminHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelAdminHeader.Name = "labelAdminHeader";
            this.labelAdminHeader.Size = new System.Drawing.Size(183, 45);
            this.labelAdminHeader.TabIndex = 0;
            this.labelAdminHeader.Text = "DashBoard";
            // 
            // panelSidebar
            // 
            this.panelSidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(52)))), ((int)(((byte)(102)))));
            this.panelSidebar.Controls.Add(this.pictureBox1);
            this.panelSidebar.Controls.Add(this.labelUserRoleName);
            this.panelSidebar.Controls.Add(this.buttonDashBoard);
            this.panelSidebar.Controls.Add(this.buttonRooms);
            this.panelSidebar.Controls.Add(this.buttonBookList);
            this.panelSidebar.Controls.Add(this.buttonEmployee);
            this.panelSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSidebar.Location = new System.Drawing.Point(0, 0);
            this.panelSidebar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panelSidebar.Name = "panelSidebar";
            this.panelSidebar.Size = new System.Drawing.Size(340, 773);
            this.panelSidebar.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(85, 23);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(43, 47);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // labelUserRoleName
            // 
            this.labelUserRoleName.AutoSize = true;
            this.labelUserRoleName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUserRoleName.ForeColor = System.Drawing.Color.White;
            this.labelUserRoleName.Location = new System.Drawing.Point(136, 30);
            this.labelUserRoleName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelUserRoleName.Name = "labelUserRoleName";
            this.labelUserRoleName.Size = new System.Drawing.Size(98, 37);
            this.labelUserRoleName.TabIndex = 6;
            this.labelUserRoleName.Text = "Admin";
            // 
            // buttonDashBoard
            // 
            this.buttonDashBoard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(242)))), ((int)(((byte)(53)))), ((int)(((byte)(87)))));
            this.buttonDashBoard.FlatAppearance.BorderSize = 0;
            this.buttonDashBoard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDashBoard.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDashBoard.ForeColor = System.Drawing.Color.White;
            this.buttonDashBoard.Image = ((System.Drawing.Image)(resources.GetObject("buttonDashBoard.Image")));
            this.buttonDashBoard.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonDashBoard.Location = new System.Drawing.Point(0, 97);
            this.buttonDashBoard.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonDashBoard.Name = "buttonDashBoard";
            this.buttonDashBoard.Size = new System.Drawing.Size(340, 94);
            this.buttonDashBoard.TabIndex = 5;
            this.buttonDashBoard.Text = "DashBoard";
            this.buttonDashBoard.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonDashBoard.UseVisualStyleBackColor = false;
            this.buttonDashBoard.Click += new System.EventHandler(this.buttonDashBoard_Click);
            // 
            // buttonRooms
            // 
            this.buttonRooms.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(122)))), ((int)(((byte)(91)))));
            this.buttonRooms.FlatAppearance.BorderSize = 0;
            this.buttonRooms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRooms.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRooms.ForeColor = System.Drawing.Color.White;
            this.buttonRooms.Image = ((System.Drawing.Image)(resources.GetObject("buttonRooms.Image")));
            this.buttonRooms.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonRooms.Location = new System.Drawing.Point(0, 279);
            this.buttonRooms.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonRooms.Name = "buttonRooms";
            this.buttonRooms.Size = new System.Drawing.Size(340, 98);
            this.buttonRooms.TabIndex = 4;
            this.buttonRooms.Text = "Manage Rooms";
            this.buttonRooms.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonRooms.UseVisualStyleBackColor = false;
            this.buttonRooms.Click += new System.EventHandler(this.buttonRooms_Click);
            // 
            // buttonBookList
            // 
            this.buttonBookList.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(0)))), ((int)(((byte)(142)))));
            this.buttonBookList.FlatAppearance.BorderSize = 0;
            this.buttonBookList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBookList.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBookList.ForeColor = System.Drawing.Color.White;
            this.buttonBookList.Image = ((System.Drawing.Image)(resources.GetObject("buttonBookList.Image")));
            this.buttonBookList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonBookList.Location = new System.Drawing.Point(0, 373);
            this.buttonBookList.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonBookList.Name = "buttonBookList";
            this.buttonBookList.Size = new System.Drawing.Size(340, 98);
            this.buttonBookList.TabIndex = 3;
            this.buttonBookList.Text = "Booking List";
            this.buttonBookList.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonBookList.UseVisualStyleBackColor = false;
            this.buttonBookList.Click += new System.EventHandler(this.buttonBookList_Click);
            // 
            // buttonEmployee
            // 
            this.buttonEmployee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(115)))), ((int)(((byte)(63)))));
            this.buttonEmployee.FlatAppearance.BorderSize = 0;
            this.buttonEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEmployee.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEmployee.ForeColor = System.Drawing.Color.White;
            this.buttonEmployee.Image = ((System.Drawing.Image)(resources.GetObject("buttonEmployee.Image")));
            this.buttonEmployee.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonEmployee.Location = new System.Drawing.Point(0, 188);
            this.buttonEmployee.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.buttonEmployee.Name = "buttonEmployee";
            this.buttonEmployee.Size = new System.Drawing.Size(340, 96);
            this.buttonEmployee.TabIndex = 2;
            this.buttonEmployee.Text = "Manage Recptionist";
            this.buttonEmployee.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonEmployee.UseVisualStyleBackColor = false;
            this.buttonEmployee.Click += new System.EventHandler(this.buttonEmployee_Click);
            // 
            // UserControlAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBoxAdminUserControlls);
            this.Controls.Add(this.panelTopBar);
            this.Controls.Add(this.panelSidebar);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "UserControlAdmin";
            this.Size = new System.Drawing.Size(1556, 773);
            this.panelTopBar.ResumeLayout(false);
            this.panelTopBar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxSignout)).EndInit();
            this.panelSidebar.ResumeLayout(false);
            this.panelSidebar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxAdminUserControlls;
        private System.Windows.Forms.Panel panelTopBar;
        private System.Windows.Forms.Label labelAdminHeader;
        private System.Windows.Forms.Panel panelSidebar;
        private System.Windows.Forms.Button buttonDashBoard;
        private System.Windows.Forms.Button buttonRooms;
        private System.Windows.Forms.Button buttonBookList;
        private System.Windows.Forms.Button buttonEmployee;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelUserRoleName;
        private System.Windows.Forms.PictureBox pictureBoxSignout;
        private System.Windows.Forms.Label labelSignout;
    }
}
