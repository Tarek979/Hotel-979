﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlLogin : UserControl
    {
        private bool  toggleEyeButton=false;
        public UserControlLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)

        {
            if(ValidateLogin())

            {
                string sql = "select * from UserInfo where UserId = '" + this.textBoxUID.Text + "' and Password = '" + this.textBoxPassword.Text + "';";
                SqlConnection sqlcon = new SqlConnection(@"DESKTOP-T03HSE8\SQLEXPRESS;Initial Catalog=hoteldb;Integrated Security=True");
                //sqlcon.Open();
                SqlCommand sqlcom = new SqlCommand(sql, sqlcon);
                SqlDataAdapter sda = new SqlDataAdapter(sqlcom);
                DataSet ds = new DataSet();
                sda.Fill(ds);

                if (ds.Tables[0].Rows.Count == 1)

                {




                    if (ds.Tables[0].Rows[0][3].ToString().Equals("admin"))
                    {
                        UserControlAdmin ucAdmin = new UserControlAdmin();
                        FormMain fromm = (FormMain)this.ParentForm;
                        fromm.panelMain.Controls.Remove(this);
                        fromm.panelMain.Controls.Add(ucAdmin);
                    }
                    else
                    {
                        UserControlReceptionist ucReceptionist = new UserControlReceptionist();
                        FormMain fromm = (FormMain)this.ParentForm;
                        fromm.panelMain.Controls.Remove(this);
                        fromm.panelMain.Controls.Add(ucReceptionist);
                    }
                }
                else
                    MessageBox.Show("User Id or Password incorrect");
            }            
            
        }

        private void buttonEye_Click(object sender, EventArgs e)
        {

            toggleEyeButton = !toggleEyeButton;
            if (!toggleEyeButton)
                this.textBoxPassword.PasswordChar = '\0';
            else
                this.textBoxPassword.PasswordChar = '*';

        }
        private bool ValidateLogin()
        {
            string uid = this.textBoxUID.Text.Trim();
            string password = textBoxPassword.Text.Trim();

            if (string.IsNullOrEmpty(uid))
            {
                MessageBox.Show("Please enter your user UserID.");
                return false;
            }

            if (string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter your password.");
                return false;
            }


            return true;
        }

        private void groupBoxWelcomePage_Enter(object sender, EventArgs e)
        {

        }

        private void textBoxUID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
