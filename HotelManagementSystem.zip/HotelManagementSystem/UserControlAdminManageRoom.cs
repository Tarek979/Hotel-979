﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlAdminManageRoom : UserControl
    {

        private CurdOperations co = new CurdOperations();
        public UserControlAdminManageRoom()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvRooms, "select * from Rooms;");
            this.dgvRooms.ClearSelection();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.co.DeleteData(this.dgvRooms,"Rooms", "RoomId");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool isValid = IsValidToSave();

            var query = "select * from Rooms where RoomId = '" + this.textBoxRoomID.Text + "'";
            var sqlUpdate = @"update Rooms
                      set RoomNumber = '" + this.textBoxRoomNumber.Text + @"',
                      RoomType = '" + this.textBoxRoomType.Text + @"',
                      Price = " + this.textBoxPrice.Text + @",
                      Availability = '" + this.textBoxAvailablity.Text + @"'
                      where RoomId = '" + this.textBoxRoomID.Text + "'; ";
            var sqlInsert = "insert into Rooms values('" + this.textBoxRoomID.Text + "', '" + this.textBoxRoomNumber.Text + "', '" + this.textBoxRoomType.Text + "', " + this.textBoxPrice.Text + ", '" + this.textBoxAvailablity.Text + "'); ";


            this.co.SaveData(query, sqlUpdate, sqlInsert, isValid);
            this.co.loadGridView(this.dgvRooms, "select * from Rooms;");
            this.dgvRooms.ClearSelection();
        }

        private bool IsValidToSave()
        {
            if (string.IsNullOrWhiteSpace(this.textBoxRoomID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxRoomNumber.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxRoomType.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxPrice.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxAvailablity.Text))
            {
                MessageBox.Show("Please fill up all the values");
                return false;
            }
            return true;
        }

       

        private void button4_Click(object sender, EventArgs e)
        {
            this.textBoxRoomID.Text = this.dgvRooms.CurrentRow.Cells[0].Value.ToString();
            this.textBoxRoomNumber.Text = this.dgvRooms.CurrentRow.Cells[1].Value.ToString();
            this.textBoxRoomType.Text = this.dgvRooms.CurrentRow.Cells[2].Value.ToString();
            this.textBoxPrice.Text = this.dgvRooms.CurrentRow.Cells[3].Value.ToString();
            this.textBoxAvailablity.Text = this.dgvRooms.CurrentRow.Cells[4].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.co.SearchData(this.dgvRooms, "select * from Rooms where RoomId='" + textBoxSearch.Text + "';   ");
        }
    }
}
