﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlReceptionistManageBookings : UserControl
    {
        private CurdOperations co = new CurdOperations();
        public UserControlReceptionistManageBookings()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvBooking, "select * from Bookings;");
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.co.SearchData(this.dgvBooking, "select * from Bookings where BookingId='" + textBoxSearch.Text + "';   ");
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            this.co.DeleteData(this.dgvBooking, "Bookings", "BookingId");
            this.co.loadGridView(this.dgvBooking, "Select * from Bookings;");
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            this.textBoxBookID.Text = this.dgvBooking.CurrentRow.Cells[0].Value.ToString();
            this.textBoxRoomID.Text = this.dgvBooking.CurrentRow.Cells[1].Value.ToString();
            this.textBoxCusID.Text = this.dgvBooking.CurrentRow.Cells[2].Value.ToString();
            this.textBoxCusName.Text = this.dgvBooking.CurrentRow.Cells[3].Value.ToString();
            this.textBoxRNum.Text = this.dgvBooking.CurrentRow.Cells[4].Value.ToString();
            this.textBoxCheckIn.Text = this.dgvBooking.CurrentRow.Cells[5].Value.ToString();
            this.textBoxCheckOut.Text = this.dgvBooking.CurrentRow.Cells[6].Value.ToString();
            this.textBoxPrice.Text = this.dgvBooking.CurrentRow.Cells[7].Value.ToString();
            this.textBoxPaymentStatus.Text = this.dgvBooking.CurrentRow.Cells[8].Value.ToString();
            this.textBoxCusNum.Text = this.dgvBooking.CurrentRow.Cells[9].Value.ToString();
            this.textBoxPayemntID.Text = this.dgvBooking.CurrentRow.Cells[10].Value.ToString();

        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool isValid = IsValidToSave();
            var query = "select * from Bookings where BookingId = '" + this.textBoxBookID.Text + "'";
            var sqlUpdate = @"update Reservation
                      set RoomId = '" + this.textBoxRoomID.Text + @"',
                      CustomerId = '" + this.textBoxCusID.Text + @"',
                      CustomerName = '" + this.textBoxCusName.Text + @"',
                      RoomNumber = '" + this.textBoxRNum.Text + @"',
                      CheckInDate = '" + this.textBoxCheckIn.Text + @"',
                      CheckOutDate = '" + this.textBoxCheckOut.Text + @"',
                      Price = " + this.textBoxPrice.Text + @",
                      PaymentStatus = '" + this.textBoxPaymentStatus.Text + @"',
                      CustomerNumber = '" + this.textBoxCusNum.Text + @"',
                      PaymentId = '" + this.textBoxPayemntID.Text + @"'
                      where BookingId = '" + this.textBoxBookID.Text + "';";
            var sqlInsert = "insert into Bookings values('" + this.textBoxBookID.Text + "', '" + this.textBoxRoomID.Text + "', '" + this.textBoxCusID.Text + "', '" + this.textBoxCusName.Text + "', '" + this.textBoxRNum.Text + "', '" + this.textBoxCheckIn.Text + "', '" + this.textBoxCheckOut.Text + "', " + this.textBoxPrice.Text + ", '" + this.textBoxPaymentStatus.Text + "', '" + this.textBoxCusNum.Text + "', '" + this.textBoxPayemntID.Text + "'); ";


            this.co.SaveData(query, sqlUpdate, sqlInsert, isValid);
            this.co.loadGridView(this.dgvBooking, "select * from Bookings;");
        }

        private bool IsValidToSave()
        {
            if (string.IsNullOrWhiteSpace(this.textBoxBookID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxRoomID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCusID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCusName.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxRNum.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCheckIn.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCheckOut.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxPrice.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxPaymentStatus.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxCusNum.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxPayemntID.Text))
            {
                MessageBox.Show("Please input all data");
                return false;
            }
            return true;
        }
    }
}
