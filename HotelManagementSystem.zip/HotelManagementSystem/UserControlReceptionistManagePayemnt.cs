﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagementSystem
{
    public partial class UserControlReceptionistManagePayemnt : UserControl
    {
        private CurdOperations co = new CurdOperations();
        public UserControlReceptionistManagePayemnt()
        {
            InitializeComponent();
            this.co.loadGridView(this.dgvPayments, "select * from Payments;");
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.co.SearchData(this.dgvPayments, "select * from Payments where PaymentId='" + textBoxSearch.Text + "';   ");
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            this.textBoxPayID.Text = this.dgvPayments.CurrentRow.Cells[0].Value.ToString();
            this.textBoxBookID.Text = this.dgvPayments.CurrentRow.Cells[1].Value.ToString();
            this.textBoxPayDate.Text = this.dgvPayments.CurrentRow.Cells[2].Value.ToString();
            this.textBoxAmmount.Text = this.dgvPayments.CurrentRow.Cells[3].Value.ToString();
            this.textBoxMethod.Text = this.dgvPayments.CurrentRow.Cells[4].Value.ToString();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            bool isValid = IsValidToSave();
            var query = "select * from Payments where PaymentId = '" + this.textBoxPayID.Text + "'";
            var sqlUpdate = @"update Payments
                      set BookingId = '" + this.textBoxBookID.Text + @"',
                      PaymentDate = '" + this.textBoxPayDate.Text + @"',
                      PaymentAmount = " + this.textBoxAmmount.Text + @",
                      PaymentMethod = '" + this.textBoxMethod.Text + @"'
                      where PaymentId = '" + this.textBoxPayID.Text + "'; ";
            var sqlInsert = "insert into Payments values('" + this.textBoxPayID.Text + "', '" + this.textBoxBookID.Text + "', '" + this.textBoxPayDate.Text + "', " + this.textBoxAmmount.Text + ", '" + this.textBoxMethod.Text + "'); ";


            this.co.SaveData(query, sqlUpdate, sqlInsert, isValid);
            this.co.loadGridView(this.dgvPayments, "select * from Payments;");
        }
        private bool IsValidToSave()
        {
            if (string.IsNullOrWhiteSpace(this.textBoxPayID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxBookID.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxPayDate.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxAmmount.Text) ||
                string.IsNullOrWhiteSpace(this.textBoxMethod.Text))
            {
                MessageBox.Show("Please fill up all the values");
                return false;
            }
            return true;
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            this.co.DeleteData(this.dgvPayments, "Payments", "PaymentId");
            this.co.loadGridView(this.dgvPayments, "select * from Payments;");
        }
    }
}
