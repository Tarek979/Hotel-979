﻿namespace HotelManagementSystem
{
    partial class UserControlReceptionist
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserControlReceptionist));
            this.groupBoxAdminUserControlls = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonCheckIn = new System.Windows.Forms.Button();
            this.panelTopBar = new System.Windows.Forms.Panel();
            this.labelAdminHeader = new System.Windows.Forms.Label();
            this.panelSidebar = new System.Windows.Forms.Panel();
            this.buttonPayments = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelUserRoleName = new System.Windows.Forms.Label();
            this.buttonCustomerEntry = new System.Windows.Forms.Button();
            this.buttonRooms = new System.Windows.Forms.Button();
            this.buttonCheckOut = new System.Windows.Forms.Button();
            this.buttonReservation = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelTopBar.SuspendLayout();
            this.panelSidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBoxAdminUserControlls
            // 
            this.groupBoxAdminUserControlls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxAdminUserControlls.Location = new System.Drawing.Point(255, 78);
            this.groupBoxAdminUserControlls.Name = "groupBoxAdminUserControlls";
            this.groupBoxAdminUserControlls.Size = new System.Drawing.Size(912, 550);
            this.groupBoxAdminUserControlls.TabIndex = 8;
            this.groupBoxAdminUserControlls.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(763, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 26);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sign out";
            this.label1.Click += new System.EventHandler(this.labelSignout_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Location = new System.Drawing.Point(828, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(68, 43);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBoxSignout_Click);
            // 
            // buttonCheckIn
            // 
            this.buttonCheckIn.BackColor = System.Drawing.Color.Green;
            this.buttonCheckIn.FlatAppearance.BorderSize = 0;
            this.buttonCheckIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCheckIn.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCheckIn.ForeColor = System.Drawing.Color.White;
            this.buttonCheckIn.Image = ((System.Drawing.Image)(resources.GetObject("buttonCheckIn.Image")));
            this.buttonCheckIn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCheckIn.Location = new System.Drawing.Point(0, 234);
            this.buttonCheckIn.Name = "buttonCheckIn";
            this.buttonCheckIn.Size = new System.Drawing.Size(255, 80);
            this.buttonCheckIn.TabIndex = 9;
            this.buttonCheckIn.Text = "Check In";
            this.buttonCheckIn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonCheckIn.UseVisualStyleBackColor = false;
            this.buttonCheckIn.Click += new System.EventHandler(this.buttonCheckIn_Click);
            // 
            // panelTopBar
            // 
            this.panelTopBar.BackColor = System.Drawing.Color.OliveDrab;
            this.panelTopBar.Controls.Add(this.label1);
            this.panelTopBar.Controls.Add(this.labelAdminHeader);
            this.panelTopBar.Controls.Add(this.pictureBox2);
            this.panelTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTopBar.Location = new System.Drawing.Point(255, 0);
            this.panelTopBar.Name = "panelTopBar";
            this.panelTopBar.Size = new System.Drawing.Size(912, 78);
            this.panelTopBar.TabIndex = 7;
            // 
            // labelAdminHeader
            // 
            this.labelAdminHeader.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelAdminHeader.AutoSize = true;
            this.labelAdminHeader.BackColor = System.Drawing.Color.Transparent;
            this.labelAdminHeader.Font = new System.Drawing.Font("Calibri", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAdminHeader.ForeColor = System.Drawing.Color.White;
            this.labelAdminHeader.Location = new System.Drawing.Point(335, 21);
            this.labelAdminHeader.Name = "labelAdminHeader";
            this.labelAdminHeader.Size = new System.Drawing.Size(152, 36);
            this.labelAdminHeader.TabIndex = 0;
            this.labelAdminHeader.Text = "Guest Entry";
            // 
            // panelSidebar
            // 
            this.panelSidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(52)))), ((int)(((byte)(102)))));
            this.panelSidebar.Controls.Add(this.buttonCheckIn);
            this.panelSidebar.Controls.Add(this.buttonPayments);
            this.panelSidebar.Controls.Add(this.pictureBox1);
            this.panelSidebar.Controls.Add(this.labelUserRoleName);
            this.panelSidebar.Controls.Add(this.buttonCustomerEntry);
            this.panelSidebar.Controls.Add(this.buttonRooms);
            this.panelSidebar.Controls.Add(this.buttonCheckOut);
            this.panelSidebar.Controls.Add(this.buttonReservation);
            this.panelSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSidebar.Location = new System.Drawing.Point(0, 0);
            this.panelSidebar.Name = "panelSidebar";
            this.panelSidebar.Size = new System.Drawing.Size(255, 628);
            this.panelSidebar.TabIndex = 6;
            // 
            // buttonPayments
            // 
            this.buttonPayments.BackColor = System.Drawing.Color.Gray;
            this.buttonPayments.FlatAppearance.BorderSize = 0;
            this.buttonPayments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPayments.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPayments.ForeColor = System.Drawing.Color.White;
            this.buttonPayments.Image = ((System.Drawing.Image)(resources.GetObject("buttonPayments.Image")));
            this.buttonPayments.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonPayments.Location = new System.Drawing.Point(0, 471);
            this.buttonPayments.Name = "buttonPayments";
            this.buttonPayments.Size = new System.Drawing.Size(255, 78);
            this.buttonPayments.TabIndex = 8;
            this.buttonPayments.Text = "Manage Payment";
            this.buttonPayments.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonPayments.UseVisualStyleBackColor = false;
            this.buttonPayments.Click += new System.EventHandler(this.buttonPayments_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(37, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 38);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // labelUserRoleName
            // 
            this.labelUserRoleName.AutoSize = true;
            this.labelUserRoleName.Font = new System.Drawing.Font("Calibri", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelUserRoleName.ForeColor = System.Drawing.Color.White;
            this.labelUserRoleName.Location = new System.Drawing.Point(75, 26);
            this.labelUserRoleName.Name = "labelUserRoleName";
            this.labelUserRoleName.Size = new System.Drawing.Size(138, 29);
            this.labelUserRoleName.TabIndex = 6;
            this.labelUserRoleName.Text = "Receptionist";
            // 
            // buttonCustomerEntry
            // 
            this.buttonCustomerEntry.BackColor = System.Drawing.Color.OliveDrab;
            this.buttonCustomerEntry.FlatAppearance.BorderSize = 0;
            this.buttonCustomerEntry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCustomerEntry.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCustomerEntry.ForeColor = System.Drawing.Color.White;
            this.buttonCustomerEntry.Image = ((System.Drawing.Image)(resources.GetObject("buttonCustomerEntry.Image")));
            this.buttonCustomerEntry.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCustomerEntry.Location = new System.Drawing.Point(0, 79);
            this.buttonCustomerEntry.Name = "buttonCustomerEntry";
            this.buttonCustomerEntry.Size = new System.Drawing.Size(255, 76);
            this.buttonCustomerEntry.TabIndex = 5;
            this.buttonCustomerEntry.Text = "Guest Entry";
            this.buttonCustomerEntry.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonCustomerEntry.UseVisualStyleBackColor = false;
            this.buttonCustomerEntry.Click += new System.EventHandler(this.buttonCustomerEntry_Click);
            // 
            // buttonRooms
            // 
            this.buttonRooms.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.buttonRooms.FlatAppearance.BorderSize = 0;
            this.buttonRooms.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonRooms.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonRooms.ForeColor = System.Drawing.Color.White;
            this.buttonRooms.Image = ((System.Drawing.Image)(resources.GetObject("buttonRooms.Image")));
            this.buttonRooms.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonRooms.Location = new System.Drawing.Point(0, 155);
            this.buttonRooms.Name = "buttonRooms";
            this.buttonRooms.Size = new System.Drawing.Size(255, 80);
            this.buttonRooms.TabIndex = 4;
            this.buttonRooms.Text = "Maanage Bookings";
            this.buttonRooms.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonRooms.UseVisualStyleBackColor = false;
            this.buttonRooms.Click += new System.EventHandler(this.buttonRooms_Click);
            // 
            // buttonCheckOut
            // 
            this.buttonCheckOut.BackColor = System.Drawing.Color.DarkRed;
            this.buttonCheckOut.FlatAppearance.BorderSize = 0;
            this.buttonCheckOut.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCheckOut.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCheckOut.ForeColor = System.Drawing.Color.White;
            this.buttonCheckOut.Image = ((System.Drawing.Image)(resources.GetObject("buttonCheckOut.Image")));
            this.buttonCheckOut.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonCheckOut.Location = new System.Drawing.Point(0, 313);
            this.buttonCheckOut.Name = "buttonCheckOut";
            this.buttonCheckOut.Size = new System.Drawing.Size(255, 80);
            this.buttonCheckOut.TabIndex = 3;
            this.buttonCheckOut.Text = "Check Out";
            this.buttonCheckOut.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonCheckOut.UseVisualStyleBackColor = false;
            this.buttonCheckOut.Click += new System.EventHandler(this.buttonCheckOut_Click);
            // 
            // buttonReservation
            // 
            this.buttonReservation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(237)))), ((int)(((byte)(115)))), ((int)(((byte)(63)))));
            this.buttonReservation.FlatAppearance.BorderSize = 0;
            this.buttonReservation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReservation.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReservation.ForeColor = System.Drawing.Color.White;
            this.buttonReservation.Image = ((System.Drawing.Image)(resources.GetObject("buttonReservation.Image")));
            this.buttonReservation.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonReservation.Location = new System.Drawing.Point(0, 393);
            this.buttonReservation.Name = "buttonReservation";
            this.buttonReservation.Size = new System.Drawing.Size(255, 78);
            this.buttonReservation.TabIndex = 2;
            this.buttonReservation.Text = "Manage Reservations";
            this.buttonReservation.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttonReservation.UseVisualStyleBackColor = false;
            this.buttonReservation.Click += new System.EventHandler(this.buttonReservation_Click);
            // 
            // UserControlReceptionist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.groupBoxAdminUserControlls);
            this.Controls.Add(this.panelTopBar);
            this.Controls.Add(this.panelSidebar);
            this.Name = "UserControlReceptionist";
            this.Size = new System.Drawing.Size(1167, 628);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelTopBar.ResumeLayout(false);
            this.panelTopBar.PerformLayout();
            this.panelSidebar.ResumeLayout(false);
            this.panelSidebar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxAdminUserControlls;
        private System.Windows.Forms.Panel panelTopBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label labelAdminHeader;
        private System.Windows.Forms.Panel panelSidebar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelUserRoleName;
        private System.Windows.Forms.Button buttonCustomerEntry;
        private System.Windows.Forms.Button buttonRooms;
        private System.Windows.Forms.Button buttonCheckOut;
        private System.Windows.Forms.Button buttonReservation;
        private System.Windows.Forms.Button buttonCheckIn;
        private System.Windows.Forms.Button buttonPayments;
    }
}
